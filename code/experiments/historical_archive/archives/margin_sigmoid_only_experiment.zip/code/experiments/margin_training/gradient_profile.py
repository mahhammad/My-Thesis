"""Diagnostic: sensitivity to Z, not merely to margin; all training labels only."""
from pathlib import Path
import json,argparse
import numpy as np,torch
from train import build_data, model_outputs, DT, StreamGraph, balanced

def diagnostic(seed=20261107,nref=72,tau=.005, z_values=None):
    torch.set_num_threads(1)
    spec,x,y,vx,vy,ids=build_data(seed,nref)
    g=StreamGraph(x,y,spec['gamma'],vx,horizon=12)
    z=torch.tensor(np.zeros((6,5)) if z_values is None else z_values,dtype=DT,requires_grad=True)
    rep,centers,margin,dist=model_outputs(g,z,y,hops=12)
    w=np.array([1/(g.k*sum(y==v)) for v in y])
    m=margin.detach().numpy()
    grad_total=torch.autograd.grad(balanced(torch.sigmoid(-margin/tau),y,g.k),z,retain_graph=True)[0].reshape(-1).detach().numpy()
    normtotal=np.linalg.norm(grad_total)
    rows=[]
    for i in range(len(y)):
        mg=torch.autograd.grad(margin[i],z,retain_graph=True)[0].reshape(-1).detach().numpy()
        mult=float(torch.sigmoid(-margin[i]/tau).detach())
        dl=-(mult*(1-mult))/tau
        grad=w[i]*dl*mg
        label='near' if abs(m[i])<=tau else ('far_wrong' if m[i]<-2*tau else ('far_correct' if m[i]>2*tau else 'mid_wrong' if m[i]<0 else 'mid_correct'))
        rows.append({'idx':i,'true_class':int(y[i]),'margin':float(m[i]),'weight':float(w[i]),'grad_margin_norm':float(np.linalg.norm(mg)),
                     'grad_loss_norm':float(np.linalg.norm(grad)),'gradient_alignment_with_total':float(grad @ grad_total / (np.linalg.norm(grad)*normtotal+1e-20)), 'label':label})
    buckets={}
    for k in ['near','mid_wrong','far_wrong','mid_correct','far_correct']:
        rs=[r for r in rows if r['label']==k]
        buckets[k]={'count':len(rs),'balanced_mass':sum(r['weight'] for r in rs),'sum_grad_norm':sum(r['grad_loss_norm'] for r in rs), 'mean_grad_margin_norm':float(np.mean([r['grad_margin_norm'] for r in rs])) if rs else None,
                    'mean_alignment':float(np.mean([r['gradient_alignment_with_total'] for r in rs])) if rs else None}
    return {'seed':seed,'nref':nref,'tau':tau,'overall_gradient_norm':float(normtotal),'buckets':buckets,'per_sample':rows}

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--seed',type=int,default=20261107);p.add_argument('--tau',type=float,default=.005);p.add_argument('--nref',type=int,default=72);p.add_argument('--policy');p.add_argument('--out',type=Path);a=p.parse_args()
 z=None
 if a.policy:z=json.loads(Path(a.policy).read_text())['Z']
 result=diagnostic(a.seed,a.nref,a.tau,z)
 print(json.dumps({'total_grad':result['overall_gradient_norm'],'buckets':result['buckets']},indent=2))
 if a.out:a.out.write_text(json.dumps(result,indent=2)+'\n')
