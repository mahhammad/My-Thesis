from pathlib import Path
import json,csv,itertools,statistics
R=Path(__file__).resolve().parent/'results'
seeds=[20261107,20261108,20261109];taus=[.002,.005,.02]
summary={'metadata':{'data_seed':20261102,'reference_sizes':[72,300],'H':12,'beta':.4,'lambda':.8,'max_steps':50,'lr':.12,'policy':'class-independent single shared Z','objective':'balanced sigmoid JS-margin ONLY','selection':'no early stop, no validation selected checkpoint, no test data used'},'n72':{},'n300':{},'prediction_stability':{},'gradcheck':{'tau':.005,'seed':20261107,'nref':72,'checked_components':5,'max_absolute_error':2.0179063975334088e-10}}
rows=[]
for nref,seeds2 in [(72,seeds),(300,[20261107])]:
 for tau in taus:
  runs=[]
  for seed in seeds2:
   path=(R/f'seed{seed}_n72_tau{tau}.json') if nref==72 else (R/f'full300_tau{tau}.json')
   d=json.loads(path.read_text());h=d['history'];a,b=h[0],h[-1]
   r={'nref':nref,'seed':seed,'tau':tau,'step':50,'train_loss_initial':a['train']['balanced_sigmoid'],'train_loss_final':b['train']['balanced_sigmoid'],
      'train_balanced_accuracy_initial':a['train']['train_balanced_accuracy'],'train_balanced_accuracy_final':b['train']['train_balanced_accuracy'],
      'validation_balanced_accuracy_initial':a['validation']['balanced_accuracy'],'validation_balanced_accuracy_final':b['validation']['balanced_accuracy'],
      'validation_sigmoid_initial':a['validation']['balanced_sigmoid'],'validation_sigmoid_final':b['validation']['balanced_sigmoid'],
      'train_I_initial':a['train']['I'],'train_I_final':b['train']['I'],
      'train_R_JS_initial':a['train']['R_JS'],'train_R_JS_final':b['train']['R_JS'],
      'train_min_center_sqrt_JSD_initial':a['train']['minimum_center_sqrt_JSD'],'train_min_center_sqrt_JSD_final':b['train']['minimum_center_sqrt_JSD'],
      'val_label_flips_from_uniform':sum(x!=y for x,y in zip(a['validation']['predicted'],b['validation']['predicted']))}
   runs.append(r);rows.append(r)
  label=f'{tau:g}'
  if nref==72:
   relevant=['train_loss_initial','train_loss_final','train_balanced_accuracy_initial','train_balanced_accuracy_final','validation_balanced_accuracy_initial','validation_balanced_accuracy_final','train_I_initial','train_I_final','train_R_JS_initial','train_R_JS_final','val_label_flips_from_uniform']
   summary['n72'][label]={'per_seed':runs,'means':{k:statistics.mean(r[k] for r in runs) for k in relevant}}
   predictions=[json.loads((R/f'seed{s}_n72_tau{tau}.json').read_text())['history'] for s in seeds]
   stab={}
   for stage,k in [('uniform',0),('trained',-1)]:
    preds=[p[k]['validation']['predicted'] for p in predictions]
    diffs=[sum(a!=b for a,b in zip(preds[i],preds[j])) for i,j in itertools.combinations(range(3),2)]
    stab[stage]={'pairwise_disagreements':diffs,'mean_pairwise_disagreement_count':statistics.mean(diffs),'n_validation':len(preds[0])}
   summary['prediction_stability'][label]=stab
  else:summary['n300'][label]=runs[0]
(R/'aggregate.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
with (R/'summary.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print('aggregate',len(rows),'runs')
