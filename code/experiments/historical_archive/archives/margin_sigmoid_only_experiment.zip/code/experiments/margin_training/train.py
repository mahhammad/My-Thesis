"""Train one shared feature-transition policy on sigmoid margin only.

The centers are differentiably rebuilt from ALL training representations on every
step. Exact expectation over capped multi-step walks, no Monte Carlo.
No validation/test labels are used for optimization or stopping.
"""
from __future__ import annotations
import argparse, json, sys, tempfile, time
from pathlib import Path
import numpy as np
import torch

ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'code/data_generator'))
sys.path.insert(0,str(ROOT/'code/experiments/multistep_policy_target_match'))
sys.path.insert(0,str(ROOT/'code/experiments/diag_max_full300'))
from generate import load_config,generate
from run import ExactGraph, DT, jsd
from stream_graph import StreamGraph

LN2=np.log(2)

def build_data(seed=20261107,nref=72):
    spec=load_config(ROOT/'code/data_generator/config.json')
    with tempfile.TemporaryDirectory() as t:
        all_data=generate(spec,t,finite_q=False)
    xx,_,yy=all_data['train']; val,_,vy=all_data['validation']
    rng=np.random.default_rng(seed)
    if nref==len(yy):
        ids=np.arange(nref)
    else:
        assert nref%len(spec['pi'])==0
        ids=np.concatenate([rng.choice(np.flatnonzero(yy==c),nref//len(spec['pi']),replace=False) for c in range(len(spec['pi']))])
    return spec,xx[ids],yy[ids],val,vy,ids

def model_outputs(graph,z,y,*,hops=12):
    idx=np.arange(len(y))
    if isinstance(graph,ExactGraph):
        reps=graph.center_train(z,idx,return_all=True)
    else:
        reps=graph.center_train(z,idx,return_all=True,max_hops=hops)
    centers=torch.stack([reps[torch.as_tensor(y==c)].mean(dim=0) for c in range(graph.k)])
    dist=jsd(reps[:,None,:],centers[None,:,:])
    scores=1-dist/LN2
    target=torch.as_tensor(y,dtype=torch.long)
    own=scores.gather(1,target[:,None]).squeeze(-1)
    competitor=scores.masked_fill(torch.nn.functional.one_hot(target,graph.k).bool(),-1e9).max(dim=1).values
    margin=own-competitor
    return reps,centers,margin,dist

def balanced(x,y,k):
    return torch.stack([x[torch.as_tensor(y==c)].mean() for c in range(k)]).mean()

def metrics(reps,centers,margin,y):
    c=centers.detach().numpy();r=reps.detach().numpy();mm=margin.detach().numpy()
    entropy=lambda a: -(a*np.log(np.maximum(a,1e-300))).sum(-1)
    I=float(entropy(c.mean(0))-entropy(c).mean())
    js=jsd(reps,centers[torch.as_tensor(y,dtype=torch.long)]).detach()
    pair=np.array([float(jsd(centers[i],centers[j]).detach()) for i in range(len(c)) for j in range(i+1,len(c))])
    train_bal=float(balanced((margin<=0).double(),y,len(c)))
    return {'train_balanced_accuracy':1-train_bal,'I':I,'R_JS':float(balanced(js,y,len(c))),
            'minimum_center_sqrt_JSD':float(np.sqrt(pair.min())),
            'mean_pair_center_JSD':float(pair.mean()),
            'margin_q10':float(np.quantile(mm,.1)),'margin_median':float(np.median(mm)),
            'margin_mean':float(np.mean(mm)),
            'margin_neg_fraction':float(np.mean(mm<=0)),
            'centers':c.tolist()}

def eval_validation(graph,z,centers,vy,tau):
    with torch.no_grad():
        rep=graph.evaluate_val(z)
        scores=1-jsd(rep[:,None,:],centers[None,:,:])/LN2
        labels=torch.as_tensor(vy,dtype=torch.long)
        pred=scores.argmax(1)
        margin=scores.gather(1,labels[:,None]).squeeze(1)-scores.masked_fill(torch.nn.functional.one_hot(labels,graph.k).bool(),-1e9).max(1).values
        acc=float(balanced((pred==labels).double(),vy,graph.k))
        sig=float(balanced(torch.sigmoid(-margin/tau),vy,graph.k))
        return {'balanced_accuracy':acc,'ordinary_accuracy':float((pred==labels).double().mean()),
                'balanced_sigmoid':sig,'mean_margin':float(balanced(margin,vy,graph.k)),
                'negative_margin_fraction':float((margin<=0).double().mean()),
                'margin_q10':float(np.quantile(margin.numpy(),0.1)),
                'predicted':pred.tolist()}

def fit(seed,nref,tau,steps,lr,hops=12,engine='stream',validate_every=10):
    torch.set_num_threads(1)
    spec,x,y,vx,vy,reference_ids=build_data(seed,nref)
    if engine=='legacy':
        graph=ExactGraph(x,y,spec['gamma'],np.arange(len(y)),vx,horizon=12)
        if hops!=12:raise ValueError('legacy engine only supports 12 hops')
    else:
        graph=StreamGraph(x,y,spec['gamma'],vx,horizon=12)
    z=torch.nn.Parameter(torch.zeros((graph.d+1,graph.d),dtype=DT))
    opt=torch.optim.Adam([z],lr=lr)
    record=[]
    start=time.perf_counter()
    for step in range(steps+1):
        rep,centers,margin,dist=model_outputs(graph,z,y,hops=hops)
        loss=balanced(torch.sigmoid(-margin/tau),y,graph.k)
        if step==0 or step==steps or step%validate_every==0:
            train={**metrics(rep,centers,margin,y),'balanced_sigmoid':float(loss.detach())}
            val=eval_validation(graph,z,centers.detach(),vy,tau)
            record.append({'step':step,'train':train,'validation':val,'elapsed_s':time.perf_counter()-start})
            print('RUN',seed,nref,tau,'step',step,'train_loss',round(train['balanced_sigmoid'],6),'train_BA',round(train['train_balanced_accuracy'],5),'val_BA',round(val['balanced_accuracy'],5),'I',round(train['I'],5),'R',round(train['R_JS'],6),'time',round(time.perf_counter()-start,2),flush=True)
        if step==steps:break
        opt.zero_grad(set_to_none=True)
        loss.backward()
        if not torch.isfinite(z.grad).all():raise RuntimeError('Non-finite policy gradient')
        opt.step()
    return {'meta':{'seed':seed,'nref':nref,'tau':tau,'steps':steps,'lr':lr,'hops_for_gradient':hops,'H_exact':12,'engine':engine,'data_seed':spec['seed'], 'no_validation_selection':True, 'policy':'single shared Z across classes', 'objective':'balanced sigmoid margin ONLY'},'history':record, 'Z':z.detach().tolist(),'reference_ids':reference_ids.tolist()}

def check_gradient(seed=20261107,nref=72,tau=.005,hops=12):
    torch.set_num_threads(1)
    spec,x,y,vx,vy,ids=build_data(seed,nref)
    g=StreamGraph(x,y,spec['gamma'],vx,horizon=12)
    rng=np.random.default_rng(11)
    z=torch.tensor(rng.normal(0,.3,size=(g.d+1,g.d)),dtype=DT,requires_grad=True)
    def obj(z):
        r,c,m,d=model_outputs(g,z,y,hops=hops)
        return balanced(torch.sigmoid(-m/tau),y,g.k)
    l=obj(z); grad=torch.autograd.grad(l,z)[0].detach().numpy()
    checks=[];eps=1e-4
    for pos in [(0,0),(1,2),(4,4),(5,0),(5,3)]:
        plus=z.detach().clone();minus=plus.clone();plus[pos]+=eps;minus[pos]-=eps
        fd=float((obj(plus)-obj(minus))/(2*eps))
        checks.append({'position':pos,'autograd':float(grad[pos]),'finite_difference':fd,'abs_error':abs(fd-float(grad[pos]))})
    worst=max(x['abs_error'] for x in checks)
    print('GRAD-CHECK',checks,'worst',worst,flush=True)
    assert worst<2e-5
    return {'gradient_checks':checks,'worst_absolute_error':worst,'tau':tau,'reference_size':nref,'hops':hops}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--seed',type=int,default=20261107);p.add_argument('--nref',type=int,default=72);p.add_argument('--tau',type=float,default=.005);p.add_argument('--steps',type=int,default=35);p.add_argument('--lr',type=float,default=.12);p.add_argument('--hops',type=int,default=12);p.add_argument('--engine',choices=['stream','legacy'],default='stream');p.add_argument('--check-gradient',action='store_true');p.add_argument('--output',type=Path);a=p.parse_args()
    r=check_gradient(a.seed,a.nref,a.tau,a.hops) if a.check_gradient else fit(a.seed,a.nref,a.tau,a.steps,a.lr,a.hops,engine=a.engine)
    if a.output:a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n')
