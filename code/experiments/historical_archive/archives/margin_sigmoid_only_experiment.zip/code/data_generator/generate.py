"""Reproducer of thesis code/data_generator/generate.py for the baseline split."""
from pathlib import Path
import numpy as np, json

def load_config(path):
    cfg=json.loads(Path(path).read_text())
    pi=np.array(cfg['class_priors']);mu=np.array(cfg['means']);sd=np.array(cfg['stds']);corr=np.array(cfg['correlation']);gamma=np.array(cfg['kernel_gamma']);missing=np.array(cfg['missing_percent'])/100
    cov=sd[:,:,None]*corr[None,:,:]*sd[:,None,:]
    return {'config':cfg, 'pi':pi,'mu':mu,'sd':sd,'corr':corr,'cov':cov,'gamma':gamma,'missing':missing,'sizes':cfg['split_sizes'],'seed':cfg['seed']}

def generate(spec,outdir,finite_q=False):
    outdir=Path(outdir)
    outdir.mkdir(parents=True,exist_ok=True)
    children=np.random.SeedSequence(spec['seed']).spawn(3)
    splits={}
    for name,child in zip(('train','validation','test'),children):
        rng=np.random.default_rng(child)
        n=spec['sizes'][name]
        y=rng.choice(len(spec['pi']),size=n,p=spec['pi'])
        x=np.empty((n,spec['mu'].shape[1]))
        for c in range(len(spec['pi'])):
            idx=np.flatnonzero(y==c)
            if len(idx): x[idx]=rng.multivariate_normal(spec['mu'][c],spec['cov'][c],size=len(idx))
        mask=rng.random(x.shape)>=spec['missing'][None,:]
        x[~mask]=np.nan
        splits[name]=(x,mask,y)
        np.savez_compressed(outdir/f'{name}.npz',x=x,mask=mask,y=y)
    return splits
