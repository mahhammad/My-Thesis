import json,tempfile
from pathlib import Path
import numpy as np,torch
import experiment as e
from generate import load_config,generate
from stream_graph import StreamGraph
from run import DT,jsd
base=Path(__file__).resolve().parent
v=json.loads((base/'results18.json').read_text())
spec=load_config(e.BASE/'code/data_generator/config.json')
with tempfile.TemporaryDirectory() as d: split=generate(spec,d)
x,_,y=split['train'];val,_,_ =split['validation']
g=StreamGraph(x,y,spec['gamma'],val,beta=.4,lam=.8,horizon=12)
torch.set_num_threads(1)
for start in ('teacher','inverse'):
 for stage in ('baseline','after_18'):
  zlist=([json.loads((e.BASE/'code/experiments/margin_training/results/full300_tau0.005.json').read_text())['Z']]*3 if start=='teacher' and stage=='baseline' else
         [q['z_recovered'] for q in json.loads((e.BASE/'inverse_class_conditional_results.json').read_text())['results']] if start=='inverse' and stage=='baseline' else
         [q['Z'] for q in v['groups'][start]['policies']])
  metrics=[]
  for c,z in enumerate(zlist):
   z=torch.as_tensor(z,dtype=DT)
   i=np.flatnonzero(y==c)
   with torch.no_grad():
    rep=g.center_train(z,i,return_all=True)
    cen=rep.mean(0)
    J=jsd(rep,cen[None,:])
    kl=(rep* (rep.clamp_min(1e-300).log()-cen.clamp_min(1e-300).log())).sum(-1)
    metrics.append((float(J.sqrt().mean()),float(kl.mean())))
  print(start,stage,'mean sqrtJSD',float(np.mean([a for a,b in metrics])),'mean KL',float(np.mean([b for a,b in metrics])),'perclass',metrics)
