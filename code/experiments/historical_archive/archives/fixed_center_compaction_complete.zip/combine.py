import json, tempfile
from pathlib import Path
import numpy as np, torch
import experiment as e
from generate import load_config,generate
from stream_graph import StreamGraph
from run import DT
base=Path(__file__).resolve().parent
torch.set_num_threads(1)
spec=load_config(e.BASE/'code/data_generator/config.json')
with tempfile.TemporaryDirectory() as d: splits=generate(spec,d)
x,_,y=splits['train'];val,_,vy=splits['validation']
g=StreamGraph(x,y,spec['gamma'],val,beta=.4,lam=.8,horizon=12)
res={'config':{'source': 'fixed center training of class-conditional source policy, 18 projected iterations per class = 6 + 12 resumed', 'data_seed':20261102,'train_n':300,'validation_n':90,'test_used':False,'beta':.4,'lambda':.8,'H':12,'center_precision':'constraint L2 <= approx 1e-6; JSD ~1e-13'},'groups':{},'targets':None}
for start in ['teacher','inverse']:
 old=json.loads((base/(start+'6.json')).read_text())
 if res['targets'] is None:res['targets']=old['targets']
 target=torch.tensor(res['targets'],dtype=DT)
 segs=[json.loads((base/f'{start}_class{c}_continued.json').read_text()) for c in range(3)]
 new=e.eval_classes(g,y,vy,[s['Z'] for s in segs],target)
 baseline=old['baselines'][start]
 after6=old['evaluations'][start]
 tr_change=sum(i!=j for i,j in zip(new['train_pred'],baseline['train_pred']))
 v_change=sum(i!=j for i,j in zip(new['val_pred'],baseline['val_pred']))
 radii_cls= np.array(new['radii_JS']); bas_cls=np.array(baseline['radii_JS'])
 res['groups'][start]={
 'baseline':baseline,'after_6':after6,'after_18':new,
 'radii_relative_changes_pct':((radii_cls/bas_cls)-1).__mul__(100).tolist(),
 'R_relative_change_pct':float(100*(new['R_JS_balanced']/baseline['R_JS_balanced']-1)),
 'n_changed_train_pred':tr_change,'n_changed_val_pred':v_change,
 'policies':segs,
 'six_step_policies':old['optimization'][start],
 'noise_start_weights':[s['noise_start_full_mask'] for s in segs],
 'total_solver_steps':18}
 print(start,'R_JS',[baseline['R_JS_balanced'],after6['R_JS_balanced'],new['R_JS_balanced']],
 'BA',[baseline['train_BA'],after6['train_BA'],new['train_BA']],
 'Val',[baseline['validation_BA'],after6['validation_BA'],new['validation_BA']],
 'I',[baseline['I'],new['I']],
 'max constraint L2',max(new['center_L2_by_class']),
 'noise',res['groups'][start]['noise_start_weights'],flush=True)

(base/'results18.json').write_text(json.dumps(res,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
