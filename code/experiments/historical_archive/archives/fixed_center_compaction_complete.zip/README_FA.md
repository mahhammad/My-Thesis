# بازتولید آزمایش کمینه‌سازی پراکندگی با مرکز ثابت

Python 3.11+ و numpy و torch نیاز است. داده‌ها در اجرا طبق بذر 20261102 دوباره ساخته می‌شوند.

این بسته همه کدها و ورودی‌های مرجع موردنیاز را شامل می‌شود. Test هرگز استفاده نمی‌شود.

برای بازتولید دقیق مطالعه:

```bash
python experiment.py --steps 6 --alpha 0.4 --starts teacher --out teacher6.json
python experiment.py --steps 6 --alpha 0.4 --starts inverse --out inverse6.json
for s in teacher inverse; do
  for c in 0 1 2; do
    python continue_one.py --start "$s" --class-id "$c" --steps 12 --alpha 0.3
  done
done
python combine.py
python additional_metrics.py
```

**مهم:** نتیجه ۱۸ مرحله‌ای «۶ گام + ۱۲ گام ادامه» است؛ خروجی‌های نهایی `results18.json` و `*_continued.json` در بسته موجودند.

دو سیاست آغازین: `teacher` یعنی سیاست مشترک قبلی با زیان حاشیه؛ `inverse` یعنی سه سیاست مستقلِ بازیابی مراکز. در هر دو، هر Z_c فقط به **فرض کلاس مبدأ** مربوط است و در تمام گشت همان مبدأ ثابت می‌ماند.

در هر گام گرادیان شعاع فرافکنی می‌شود و با ژاکوبین قید مرکز مجدداً بازیابی می‌شود. هر سه مرکز واقعی، برحسب L2 حداکثر در حد 4e-7 از هدف فاصله دارند. این فقط یک آزمایش موضعی است؛ بهینگی سراسری ثابت نشده است.

گزارش کامل روی GitHub: `code/experiments/fixed_center_compaction/REPORT_FA.md` در برنچ `chapter4`، کامیت `a61e1d5fc5f1ce2505a9f1444aa37b5d38e5c5a5`.
