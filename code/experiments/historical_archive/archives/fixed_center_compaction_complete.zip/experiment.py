"""Fixed-center dispersion minimization of class-conditioned feature policies.

Uses exact multi-step walk expectations, one Z_c per starting-class hypothesis.
Minimize class-mean JSD of origin representation to a fixed margin-trained center,
subject to realized class center equal to the target center. No test data accessed.
"""
from pathlib import Path
import json, os, sys, time, tempfile, argparse
import numpy as np
import torch

BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'code/data_generator'))
sys.path.insert(0,str(BASE/'code/experiments/multistep_policy_target_match'))
sys.path.insert(0,str(BASE/'code/experiments/diag_max_full300'))
from generate import load_config,generate
from run import jsd,DT
from stream_graph import StreamGraph

LN2=float(np.log(2.))
CLASSES=3

def center_row(z):
    return z-z.mean(dim=1,keepdim=True)

def class_stats(g,ind,z,target,need_grad=False):
    reps=g.center_train(z,ind,return_all=True)
    center=reps.mean(0)
    vals=jsd(reps,target[None,:])
    radius=vals.mean()
    err=center[:g.k-1]-target[:g.k-1]
    return radius,err,center,reps

def jacobian(g,ind,z,target,center):
    J=torch.stack([torch.autograd.grad(center[k],z,retain_graph=True)[0].reshape(-1) for k in range(g.k-1)])
    return J

def restore(g,ind,z0,target,tol=1e-6,rounds=6):
    z=center_row(z0.detach())
    for j in range(rounds):
        z=z.detach().requires_grad_(True)
        center=g.center_train(z,ind)
        err=(center[:g.k-1]-target[:g.k-1])
        norm=float(torch.linalg.norm(err).detach())
        if norm<tol: return z.detach(),norm,j
        J=jacobian(g,ind,z,target,center).detach()
        mat=J@J.T+1e-10*torch.eye(g.k-1,dtype=DT)
        dz=J.T@torch.linalg.solve(mat,-err.detach())
        if not torch.isfinite(dz).all():return None,norm,j
        z=center_row(z.detach()+dz.reshape(z.shape))
    with torch.no_grad():
        c=g.center_train(z,ind)
        norm=float(torch.linalg.norm(c[:g.k-1]-target[:g.k-1]))
    return z.detach(),norm,rounds

# Each step measures the radius and gradient, projects into tangent space, then
# restores nonlinear center constraint with damped Newton and an Armijo check.
def solve_one(g,ind,target,init,init_name,step_size=.35,steps=30,ctol=1e-6):
    z0=center_row(init.detach().clone())
    z,err,init_corr=restore(g,ind,z0,target,tol=ctol,rounds=9)
    if z is None or err>ctol*2:raise RuntimeError(f'Cannot project feasible initial policy (error={err:g})')
    trace=[];time0=time.perf_counter();eta=step_size
    for step in range(steps+1):
        z=z.detach().requires_grad_(True)
        rad,err,center,reps=class_stats(g,ind,z,target)
        r=float(rad.detach());n=float(torch.linalg.norm(err.detach()))
        dists=jsd(reps,center[None,:]).detach()
        trace.append(dict(step=step, R_JS_fixed_target=r,R_JS_actual_center=float(dists.mean()),center_L2=n,
                          target_JSD=float(jsd(center.detach(),target)),
                          mean_entropy=float((-(reps.detach()*reps.detach().clamp_min(1e-300).log()).sum(-1)).mean()),
                          center=center.detach().tolist(),step_scale=eta))
        if step%5==0 or step==steps:
            print(f'{init_name} step {step:3d}, R={r:.9f}, centerL2={n:.2e}, sec={time.perf_counter()-time0:.1f}',flush=True)
        if step==steps:break
        gvec=torch.autograd.grad(rad,z,retain_graph=True)[0].flatten().detach()
        J=jacobian(g,ind,z,target,center).detach()
        mat=J@J.T+1e-9*torch.eye(g.k-1,dtype=DT)
        direction=-gvec+J.T@torch.linalg.solve(mat,J@gvec)
        direction=direction.reshape(z.shape)
        direction=center_row(direction)
        gn=float(torch.linalg.norm(direction))
        if gn>1e-14:
            direction=direction/gn
        trace[-1]['projected_grad_norm']=gn
        if gn<1e-10:
            print('projected stationarity',gn,flush=True);break
        accepted=False
        for alpha in [eta, eta/2, eta/4,eta/8,eta/16]:
            candidate=center_row(z.detach()+alpha*direction)
            candidate,cs_err,restore_steps=restore(g,ind,candidate,target,ctol,4)
            if candidate is None or cs_err>ctol*2:continue
            with torch.no_grad():newr=float(class_stats(g,ind,candidate,target)[0])
            if newr<r-1e-13:
                z=candidate.detach()
                trace[-1]['accepted_alpha']=alpha
                trace[-1]['restoration_iterations']=restore_steps
                trace[-1]['accepted_reduction']=r-newr
                eta=min(alpha*1.3,1.0)
                accepted=True;break
        if not accepted:
            print(f'{init_name} LINE_SEARCH_FAILED step {step} R {r:.9f} gproj {gn:.3g}',flush=True);break
    with torch.no_grad():
        rad,err,center,reps=class_stats(g,ind,z,target)
        dist=jsd(reps,center[None,:]);start_p=torch.softmax(z[g.d],-1)
    return dict(init=init_name, initial_correction_steps=init_corr,trace=trace,iterations=len(trace)-1,
       Z=z.detach().tolist(),center=center.detach().tolist(),R_JS_fixed=float(rad),
       R_JS_actual=float(dist.mean()),center_L2=float(torch.linalg.norm(err)),
       center_JSD=float(jsd(center,target)),radius_std=float(dist.std(unbiased=False)),
       noise_start_full_mask=float(start_p[[2,4]].sum()),duration_s=time.perf_counter()-time0)

def eval_classes(g,ys,val_y,zs,target):
    with torch.no_grad():
        cls_scores=[];val_scores=[];centers=[];rads=[]
        for c in range(g.k):
            z=torch.as_tensor(zs[c],dtype=DT)
            rep=g.center_train(z,np.arange(g.n),return_all=True)
            cen=rep[torch.as_tensor(ys==c)].mean(0)
            cls_scores.append(1-jsd(rep,cen[None,:])/LN2)
            val_scores.append(1-jsd(g.evaluate_val(z),cen[None,:])/LN2)
            centers.append(cen)
            rads.append(float(jsd(rep[torch.as_tensor(ys==c)],cen[None,:]).mean()))
        t=torch.stack(cls_scores,dim=-1).argmax(-1).numpy(); v=torch.stack(val_scores,dim=-1).argmax(-1).numpy()
        acc=lambda p,y: float(np.mean([np.mean(p[y==c]==c) for c in range(g.k)]))
        center=torch.stack(centers)
        ent=lambda x:-(x*x.clamp_min(1e-300).log()).sum(-1)
        Vavg=center.mean(0)
        return {'train_BA':acc(t,ys),'validation_BA':acc(v,val_y),
                'train_correct_count':int((t==ys).sum()),'validation_correct_count':int((v==val_y).sum()),
                'train_pred':t.tolist(),'val_pred':v.tolist(),'radii_JS':rads,'R_JS_balanced':float(np.mean(rads)),
                'center_L2_by_class':torch.linalg.norm(center-target,dim=-1).tolist(),
                'center_JS_by_class':jsd(center,target).tolist(),
                'I':float(ent(Vavg)-ent(center).mean()),'centers':center.tolist()}

def main():
    p=argparse.ArgumentParser();p.add_argument('--steps',type=int,default=30);p.add_argument('--alpha',type=float,default=.35)
    p.add_argument('--starts',choices=['teacher','inverse','both'],default='both');p.add_argument('--out',type=Path,default=Path(__file__).resolve().parent/'results.json')
    a=p.parse_args();torch.set_num_threads(1)
    spec=load_config(BASE/'code/data_generator/config.json')
    with tempfile.TemporaryDirectory() as d: split=generate(spec,d)
    xx,_,y=split['train'];val,_,vy=split['validation']
    g=StreamGraph(xx,y,spec['gamma'],val,beta=.4,lam=.8,horizon=12)
    prev=json.load(open(BASE/'code/experiments/margin_training/results/full300_tau0.005.json'))
    inverse=json.load(open(BASE/'inverse_class_conditional_results.json'))
    target=torch.as_tensor(prev['history'][-1]['train']['centers'],dtype=DT)
    teacher=torch.as_tensor(prev['Z'],dtype=DT)
    inverse_z=torch.as_tensor([j['z_recovered'] for j in inverse['results']],dtype=DT)
    init_zs={'teacher':[teacher]*g.k,'inverse':[inverse_z[c] for c in range(g.k)]}
    result={'config':dict(seed=spec['seed'],train=300,val=90,test_used=False,kind='class-conditional Z_c, unchanged per walk for each starting-class hypothesis',beta=.4,lam=.8,H=12,optimizer='projected tangent gradient with nonlinear center restoration',steps=a.steps,initial_alpha=a.alpha),
            'targets':target.tolist(), 'baselines':{}, 'optimization':{},'evaluations':{}}
    for start,zs in init_zs.items():
        result['baselines'][start]=eval_classes(g,y,vy,zs,target)
        print('BASELINE',start,result['baselines'][start]['R_JS_balanced'],result['baselines'][start]['train_BA'],result['baselines'][start]['validation_BA'],flush=True)
    for start in ['teacher','inverse']:
        if a.starts not in (start,'both'):continue
        res=[]
        for c in range(g.k):
            ind=np.flatnonzero(y==c)
            res.append(solve_one(g,ind,target[c],init_zs[start][c],f'{start}_class{c}',a.alpha,a.steps))
        result['optimization'][start]=res
        result['evaluations'][start]=eval_classes(g,y,vy,[r['Z'] for r in res],target)
        print('DONE',start,'R',result['evaluations'][start]['R_JS_balanced'],'TRAIN',result['evaluations'][start]['train_BA'],'VAL',result['evaluations'][start]['validation_BA'],flush=True)
        a.out.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    a.out.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
if __name__=='__main__':main()
