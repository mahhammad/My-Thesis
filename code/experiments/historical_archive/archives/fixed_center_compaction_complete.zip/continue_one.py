import argparse, json, tempfile
from pathlib import Path
import numpy as np, torch
import experiment as e
from generate import load_config,generate
from stream_graph import StreamGraph
from run import DT
p=argparse.ArgumentParser();p.add_argument('--start',choices=['teacher','inverse'],required=True);p.add_argument('--class-id',type=int,required=True);p.add_argument('--steps',type=int,default=10);p.add_argument('--alpha',type=float,default=.3);a=p.parse_args()
torch.set_num_threads(1)
base=Path(__file__).resolve().parent
prev=json.loads((base/(a.start+'6.json')).read_text())
spec=load_config(e.BASE/'code/data_generator/config.json')
with tempfile.TemporaryDirectory() as d: splits=generate(spec,d)
x,_,y=splits['train'];val,_,_ =splits['validation']
g=StreamGraph(x,y,spec['gamma'],val,beta=.4,lam=.8,horizon=12)
target=torch.tensor(prev['targets'][a.class_id],dtype=DT)
z=torch.tensor(prev['optimization'][a.start][a.class_id]['Z'],dtype=DT)
rec=e.solve_one(g,np.flatnonzero(y==a.class_id),target,z,f'{a.start}_class{a.class_id}_cont',a.alpha,a.steps)
f=base/(f'{a.start}_class{a.class_id}_continued.json');f.write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n')
print('SAVED',f,flush=True)
