"""Controlled train-size study of sigmoid JS-margin only on the original fixed data.

For each size n in [50, 100, 150, 200, 250, 300], create five
reproducible, nested, proportional-stratified subsets from ONE 300-sample
training split. The full 300-reference case is unique and run once.

Each run: one class-shared 6x5 Z, zero init, exact 12-step expected walk,
Adam 50 steps @ lr=0.12, tau=0.005; no I or R in objective.
Bayes oracles are diagnostic ONLY; the generator parameters are never used
for walk-policy training apart from fixed kernel scales from config.
"""
import argparse, json, sys, tempfile, time
from pathlib import Path
import numpy as np
import torch

ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'code/data_generator'))
sys.path.insert(0,str(ROOT/'code/experiments/multistep_policy_target_match'))
sys.path.insert(0,str(ROOT/'code/experiments/diag_max_full300'))
from generate import load_config,generate
from stream_graph import StreamGraph
from run import DT,jsd

SIZES=(50,100,150,200,250,300)
SEEDS=(20261107,20261108,20261109,20261110,20261111)
TAU=.005
LR=.12
STEPS=50
H=12
BETA=.4
LAMBDA=.8

def bayes_logits(spec,x):
    x=np.asarray(x,float)
    log_l=np.zeros((len(x),len(spec['pi'])),float)
    obs=np.isfinite(x)
    for pattern in np.unique(obs,axis=0):
        rows=np.flatnonzero(np.all(obs==pattern,axis=1))
        idx=np.flatnonzero(pattern)
        if not len(idx):continue
        for c in range(len(spec['pi'])):
            cov=spec['cov'][c][np.ix_(idx,idx)]
            chol=np.linalg.cholesky(cov)
            residual=(x[np.ix_(rows,idx)]-spec['mu'][c,idx]).T
            white=np.linalg.solve(chol,residual)
            log_l[rows,c]-=(.5*np.sum(white*white,axis=0)
                +np.log(np.diag(chol)).sum()+.5*len(idx)*np.log(2*np.pi))
    return log_l

def class_quota(total,n):
    wanted=n*np.array(total)/sum(total)
    quota=np.floor(wanted).astype(int)
    remainder=n-int(quota.sum())
    if remainder:
        order=np.argsort(-(wanted-quota),kind='stable')
        quota[order[:remainder]]+=1
    if not (np.sum(quota)==n and np.all(quota<=total)):
        raise AssertionError((n,quota,total))
    return quota

def subsets(y,seeds=SEEDS,sizes=SIZES):
    counts=np.bincount(y,minlength=3)
    quotas={n:class_quota(counts,n) for n in sizes}
    for seed in seeds:
        rng=np.random.default_rng(seed)
        per_class=[rng.permutation(np.flatnonzero(y==c)) for c in range(len(counts))]
        for n in sizes:
            if n==len(y):
                ids=np.arange(len(y))
                if seed!=seeds[0]:continue
            else:
                ids=np.concatenate([per_class[c][:quotas[n][c]] for c in range(len(counts))])
            yield seed,n,ids,quotas[n]

def ba(pred,y,k):
    return float(np.mean([np.mean(pred[y==c]==c) for c in range(k)]))

def train_report(graph,z,y,tau):
    reps=graph.center_train(z,np.arange(len(y)),return_all=True)
    centers=torch.stack([reps[torch.as_tensor(y==c)].mean(dim=0) for c in range(graph.k)])
    scores=1-jsd(reps[:,None,:],centers[None,:,:])/np.log(2)
    truth=torch.as_tensor(y,dtype=torch.long)
    competitors=scores.masked_fill(torch.nn.functional.one_hot(truth,graph.k).bool(),-1e9).max(dim=-1).values
    margin=scores.gather(1,truth[:,None]).squeeze(1)-competitors
    balanced_loss=torch.stack([torch.sigmoid(-margin[truth==c]/tau).mean() for c in range(graph.k)]).mean()
    with torch.no_grad():
        train_pred=scores.argmax(dim=-1).numpy()
        train_ba=ba(train_pred,y,graph.k)
        I=float((-((centers.mean(0))*torch.log(centers.mean(0))).sum()+
                (centers*torch.log(centers)).sum(-1).mean()))
        rad=float(torch.stack([jsd(reps[truth==c],centers[c]).mean() for c in range(graph.k)]).mean())
        margin_np=margin.detach().numpy()
        margin_q10=float(np.quantile(margin_np,.1))
    return {'loss':float(balanced_loss.detach()),'train_BA':train_ba,
            'I':I,'R_JS':rad,'margin_q10':margin_q10}, centers, balanced_loss

def eval_validation(graph,z,centers,vy):
    with torch.no_grad():
        p=graph.evaluate_val(z)
        pred=jsd(p[:,None,:],centers[None,:,:]).argmin(dim=-1).numpy()
    return ba(pred,vy,centers.shape[0])

def fit_one(spec,x,y,val,vy,seed,n,ids,quota,steps=STEPS,tau=TAU,lr=LR):
    graph=StreamGraph(x,y,spec['gamma'],val,beta=BETA,lam=LAMBDA,horizon=H)
    z=torch.nn.Parameter(torch.zeros((graph.d+1,graph.d),dtype=DT))
    opt=torch.optim.Adam([z],lr=lr)
    timeline=[]
    t0=time.perf_counter()
    for t in range(steps+1):
        metrics,centers,loss=train_report(graph,z,y,tau)
        if t in (0,10,20,30,40,steps):
            timeline.append({'step':t,'train':metrics,
                             'validation_BA':eval_validation(graph,z,centers.detach(),vy),
                             'wall_time_sec':time.perf_counter()-t0})
        if t==steps:break
        opt.zero_grad(set_to_none=True)
        loss.backward()
        if not torch.isfinite(z.grad).all():raise RuntimeError('nonfinite gradient')
        opt.step()
    l=bayes_logits(spec,x)
    oracle_MAP=np.argmax(l+np.log(spec['pi'])[None,:],axis=1)
    oracle_balanced=np.argmax(l,axis=1)
    return {'nref':n,'reference_seed':seed,'reference_ids':ids.tolist(),
            'train_counts':np.bincount(y,minlength=graph.k).tolist(),
            'oracle_MAP_BA':ba(oracle_MAP,y,graph.k),
            'oracle_balanced_BA':ba(oracle_balanced,y,graph.k),
            'initial':timeline[0], 'final':timeline[-1], 'checkpoints':timeline,
            'Z_final':z.detach().tolist(),
            'elapsed_seconds':time.perf_counter()-t0}

def aggregate(runs,sizes=SIZES):
    out=[]
    for n in sizes:
        r=[x for x in runs if x['nref']==n]
        if not r:continue
        fields={'Bayes_MAP_BA':[x['oracle_MAP_BA'] for x in r],
                'Bayes_balanced_BA':[x['oracle_balanced_BA'] for x in r],
                'uniform_train_BA':[x['initial']['train']['train_BA'] for x in r],
                'trained_train_BA':[x['final']['train']['train_BA'] for x in r],
                'gain_train_BA':[x['final']['train']['train_BA']-x['initial']['train']['train_BA'] for x in r],
                'uniform_val_BA':[x['initial']['validation_BA'] for x in r],
                'trained_val_BA':[x['final']['validation_BA'] for x in r],
                'initial_loss':[x['initial']['train']['loss'] for x in r],
                'final_loss':[x['final']['train']['loss'] for x in r],
                'initial_I':[x['initial']['train']['I'] for x in r],
                'final_I':[x['final']['train']['I'] for x in r],
                'initial_R_JS':[x['initial']['train']['R_JS'] for x in r],
                'final_R_JS':[x['final']['train']['R_JS'] for x in r]}
        cols={}
        for name,x in fields.items():
            a=np.asarray(x,float)
            cols[name]={'mean':float(a.mean()),
                        'variance_sample':float(a.var(ddof=1)) if len(a)>1 else None,
                        'std_sample':float(a.std(ddof=1)) if len(a)>1 else None,
                        'observations':a.tolist()}
        out.append({'n_train':n,'n_subsets':len(r),
                    'counts':r[0]['train_counts'], 'metrics':cols})
    return out

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--out',type=Path,default=ROOT/'code/experiments/margin_training/results/size_study')
    p.add_argument('--steps',type=int,default=STEPS)
    p.add_argument('--tau',type=float,default=TAU)
    p.add_argument('--seeds',type=int,default=len(SEEDS))
    p.add_argument('--sizes',type=int,nargs='+',default=list(SIZES))
    args=p.parse_args()
    torch.set_num_threads(1)
    args.out.mkdir(parents=True,exist_ok=True)
    spec=load_config(ROOT/'code/data_generator/config.json')
    with tempfile.TemporaryDirectory() as temp:
        splits=generate(spec,temp,finite_q=False)
    xx,_,yy=splits['train']
    val,_,vy=splits['validation']
    samples=list(subsets(yy,seeds=SEEDS[:args.seeds],sizes=args.sizes))
    runs=[]
    for j,(seed,n,ids,quota) in enumerate(samples,1):
        fname=args.out/f'n{n}_seed{seed}.json'
        if fname.is_file():
            run=json.loads(fname.read_text())
            print('REUSED',j,len(samples),seed,n,flush=True)
        else:
            run=fit_one(spec,xx[ids],yy[ids],val,vy,seed,n,ids,quota,steps=args.steps,tau=args.tau)
            fname.write_text(json.dumps(run,indent=2,ensure_ascii=False)+'\n')
            print('DONE',j,len(samples),'size',n,'seed',seed,'train_BA',
                  round(run['initial']['train']['train_BA'],5),'->',
                  round(run['final']['train']['train_BA'],5),'Bayes_MAP',
                  round(run['oracle_MAP_BA'],5),'time',round(run['elapsed_seconds'],2),flush=True)
        runs.append(run)
        result={'meta':{'base_data_seed':spec['seed'],'reference_seeds':list(SEEDS[:args.seeds]),
                        'sizes':args.sizes,'n_train_full':len(yy),'train_class_counts':np.bincount(yy).tolist(),
                        'sampling':'nested proportional stratification by empirical class count; reuse 300 full only once',
                        'only_one_fixed_synthetic_dataset':True,
                        'variance':'sample variance ddof=1 over reference subsets, conditional on same 300; unavailable for n=300',
                        'objective':'balanced sigmoid JS-margin alone, one shared Z, no I or R terms',
                        'policy':'zero logits; Adam 50 steps lr .12; tau .005; beta .4 lambda .8 H12',
                        'train':'in-sample origin-excluding walk; labels used for Z and centers',
                        'validation':'same 90 out-of-reference examples; not used for optimizer or stopping',
                        'test':'not touched'},
                'aggregate':aggregate(runs,args.sizes),
                'raw_files':[f'n{x["nref"]}_seed{x["reference_seed"]}.json' for x in runs]}
        (args.out/'summary.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    print('COMPLETE',len(runs),flush=True)

if __name__=='__main__':main()
