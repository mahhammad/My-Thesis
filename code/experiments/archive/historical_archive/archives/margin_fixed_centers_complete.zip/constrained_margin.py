"""Optimize balanced sigmoid JS classification margins while holding each class center fixed.

Each Z_c governs the entire walk conditional on STARTING CLASS HYPOTHESIS c.
No ground-truth validation/test labels enter training. Exact deterministic walk expectation.

Reproduce from the fixed_center_compaction_complete archive extracted to the same folder:
    OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python constrained_margin.py --cycles 20
"""
from pathlib import Path
import argparse, json, tempfile, time
import numpy as np
import torch
from experiment import BASE, load_config, generate, StreamGraph, DT, jsd, LN2, center_row, restore


def per_class_scores(graph, labels, z, c, all_idx):
    reps=graph.center_train(z,all_idx,return_all=True)
    ctr=reps[torch.as_tensor(labels==c)].mean(dim=0)
    return 1-jsd(reps,ctr[None,:])/LN2,ctr


def loss_margins(score, y, tau=0.005):
    yi=torch.as_tensor(y,dtype=torch.long)
    own=score.gather(1,yi[:,None]).squeeze(1)
    other=score.masked_fill(torch.nn.functional.one_hot(yi,score.shape[1]).bool(),-1e9).max(1).values
    m=own-other
    losses=torch.sigmoid(-m/tau)
    objective=torch.stack([losses[yi==c].mean() for c in range(score.shape[1])]).mean()
    return objective,m


def accuracy_score(pred,y,k):
    return float(np.mean([np.mean(pred[y==c]==c) for c in range(k)]))


def evaluate(graph,y,vy,zs,targets,tau=.005):
    with torch.no_grad():
        all_idx=np.arange(graph.n)
        score=[];vs=[];vscore=[];r=[]
        for c,z in enumerate(zs):
            s,v=per_class_scores(graph,y,z,c,all_idx)
            score.append(s);vs.append(v)
            vscore.append(1-jsd(graph.evaluate_val(z),v[None,:])/LN2)
            rep=graph.center_train(z,np.flatnonzero(y==c),return_all=True)
            r.append(float(jsd(rep,v[None,:]).mean()))
        score=torch.stack(score,dim=1)
        vs=torch.stack(vs)
        loss,m=loss_margins(score,y,tau)
        train_pred=score.argmax(dim=1).numpy()
        val_pred=torch.stack(vscore,dim=1).argmax(dim=1).numpy()
        ent=lambda w:-(w*w.clamp_min(1e-300).log()).sum(dim=-1)
        out={"loss":float(loss),"train_BA":accuracy_score(train_pred,y,graph.k),
             "val_BA":accuracy_score(val_pred,vy,graph.k),
             "train_correct":int((train_pred==y).sum()),"val_correct":int((val_pred==vy).sum()),
             "R_JS":float(np.mean(r)),"R_by_class":r,
             "I":float(ent(vs.mean(0))-ent(vs).mean()),
             "center_L2_max":float(torch.linalg.norm(vs-targets,dim=1).max()),
             "center_L2_by_class":torch.linalg.norm(vs-targets,dim=1).tolist(),
             "centers":vs.tolist(),"margin_quantiles":np.quantile(m.numpy(),[.0,.1,.25,.5,.75,1.]).tolist(),
             "train_preds":train_pred.tolist(),"val_preds":val_pred.tolist()}
        return out


def make_scores(graph,y,zs,idx):
    with torch.no_grad():
        ss=[per_class_scores(graph,y,z,c,idx)[0] for c,z in enumerate(zs)]
    return torch.stack(ss,dim=1)


def optimize(graph,y,vy,targets,start_zs,name,cycles=20,step_size=.25,ctol=5e-7,tau=.005,checkpoint_every=5,outpath=None):
    k=graph.k;idx=np.arange(graph.n)
    class_indices=[np.flatnonzero(y==c) for c in range(k)]
    zs=[]
    for c in range(k):
        z,e,_=restore(graph,class_indices[c],center_row(start_zs[c]),targets[c],tol=ctol,rounds=8)
        if e>ctol*2:raise RuntimeError(f'initial center constraint violated: {name} {c} {e}')
        zs.append(z.detach())
    score=make_scores(graph,y,zs,idx)
    history=[];events=[];t0=time.perf_counter()
    start_eval=evaluate(graph,y,vy,zs,targets,tau)
    history.append(dict(cycle=0,metrics=start_eval))
    print(name,'INIT', 'loss',round(start_eval['loss'],8),'BA',round(start_eval['train_BA'],6),
          'Val',round(start_eval['val_BA'],6),'R',round(start_eval['R_JS'],8),flush=True)
    for epoch in range(1,cycles+1):
        for c in range(k):
            z=zs[c].detach().requires_grad_(True)
            scores_c,center=per_class_scores(graph,y,z,c,idx)
            s=score.clone().detach()
            s[:,c]=scores_c
            obj,_=loss_margins(s,y,tau)
            old=float(obj.detach())
            gvec=torch.autograd.grad(obj,z,retain_graph=True)[0].flatten().detach()
            J=torch.stack([torch.autograd.grad(center[t],z,retain_graph=t<k-2)[0].flatten() for t in range(k-1)]).detach()
            dp=-gvec+J.T@torch.linalg.solve(J@J.T+1e-10*torch.eye(k-1,dtype=DT),J@gvec)
            dp=center_row(dp.reshape(z.shape)).flatten()
            gproj=float(dp.norm())
            if gproj<1e-11:
                events.append({'cycle':epoch,'class':c,'accepted':False,'reason':'projected_stagnation','grad_proj':gproj});continue
            direction=dp.reshape(z.shape)/gproj
            accepted=False
            for alpha in [step_size,step_size/2,step_size/4,step_size/8,step_size/16,step_size/32,step_size/64]:
                candidate=center_row(z.detach()+alpha*direction)
                candidate,error,rest_steps=restore(graph,class_indices[c],candidate,targets[c],tol=ctol,rounds=5)
                if candidate is None or error>ctol:continue
                with torch.no_grad():
                    sc,cc=per_class_scores(graph,y,candidate,c,idx)
                    trial=score.clone();trial[:,c]=sc
                    trial_loss=float(loss_margins(trial,y,tau)[0])
                if trial_loss<old-1e-11:
                    zs[c]=candidate.detach();score[:,c]=sc.detach();accepted=True
                    events.append({'cycle':epoch,'class':c,'accepted':True,'alpha':alpha,
                                   'gain':old-trial_loss,'constraint_L2':error,'projected_grad':gproj,
                                   'restoration_iterations':rest_steps})
                    break
            if not accepted:
                events.append({'cycle':epoch,'class':c,'accepted':False,'reason':'line_search_failed',
                               'projected_grad':gproj})
        if epoch%checkpoint_every==0 or epoch==cycles:
            stat=evaluate(graph,y,vy,zs,targets,tau)
            history.append({'cycle':epoch,'metrics':stat})
            print(name,'EPOCH',epoch,'loss',round(stat['loss'],8),'BA',round(stat['train_BA'],6),
                  'Val',round(stat['val_BA'],6),'R',round(stat['R_JS'],8),
                  'center_L2',f"{stat['center_L2_max']:.2e}",'time',round(time.perf_counter()-t0,1),flush=True)
            if outpath:
                save={'config':{'label':name,'cycles':cycles,'alpha':step_size,'tau':tau,'ctol':ctol,
                      'seed':20261102,'n_train':300,'n_validation':90,'test_used':False,'beta':.4,'lambda':.8,'H':12,
                      'solver':'cyclic classwise projected margin gradient and nonlinear center restoration',
                      'candidate_inference':'class-conditioned hypothesis, fixed Z_c within entire origin walk'},
                      'targets':targets.tolist(),'history':history,'events':events,
                      'policies':torch.stack(zs).tolist(),'run_duration_s':time.perf_counter()-t0}
                outpath.write_text(json.dumps(save,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    return save


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--cycles',type=int,default=20)
    p.add_argument('--step',type=float,default=.25)
    p.add_argument('--starts',choices=('teacher','compact_teacher','compact_inverse','all'),default='all')
    p.add_argument('--out-dir',type=Path,default=BASE/'margin_fixed_center_results')
    opt=p.parse_args()
    torch.set_num_threads(1)
    spec=load_config(BASE/'code/data_generator/config.json')
    with tempfile.TemporaryDirectory() as tmp:
        data=generate(spec,tmp)
    x,_,y=data['train'];v,_,vy=data['validation']
    graph=StreamGraph(x,y,spec['gamma'],v,beta=.4,lam=.8,horizon=12)
    old=json.loads((BASE/'code/experiments/margin_training/results/full300_tau0.005.json').read_text())
    targets=torch.as_tensor(old['history'][-1]['train']['centers'],dtype=DT)
    ref=torch.as_tensor(old['Z'],dtype=DT)
    comp=json.loads((BASE/'results18.json').read_text())
    starts={'teacher':[ref]*graph.k,
            'compact_teacher':[torch.as_tensor(q['Z'],dtype=DT) for q in comp['groups']['teacher']['policies']],
            'compact_inverse':[torch.as_tensor(q['Z'],dtype=DT) for q in comp['groups']['inverse']['policies']]}
    opt.out_dir.mkdir(parents=True,exist_ok=True)
    for name,zs in starts.items():
        if opt.starts not in ('all',name):continue
        optimize(graph,y,vy,targets,zs,name,cycles=opt.cycles,step_size=opt.step,
                 outpath=opt.out_dir/f'{name}.json')

if __name__=='__main__':main()
