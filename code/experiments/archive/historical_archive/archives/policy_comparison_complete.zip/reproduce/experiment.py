"""Compare class-hypothesis margin training vs shared-Z inverse on identical synthetic train.
Uses exact StreamGraph and correct hypothesis-specific train scores.
Reproduce: python experiment.py --task both --steps 50
No Test split is ever accessed.
"""
import argparse, time, os, sys, json, tempfile
from pathlib import Path
import numpy as np, torch
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'code/data_generator'))
sys.path.insert(0,str(ROOT/'code/experiments/multistep_policy_target_match'))
sys.path.insert(0,str(ROOT/'code/experiments/diag_max_full300'))
from generate import load_config,generate
from run import jsd,DT
from stream_graph import StreamGraph

HERE=Path(__file__).resolve().parent
LN2=np.log(2)
def balanced_acc(pred,y,k=3):return float(np.mean([np.mean(pred[y==c]==c) for c in range(k)]))
def bal_loss(loss,y,k):return torch.stack([loss[torch.as_tensor(y==c)].mean() for c in range(k)]).mean()
def data():
 spec=load_config(ROOT/'code/data_generator/config.json')
 with tempfile.TemporaryDirectory() as d:
  splits=generate(spec,d)
 x,_,y=splits['train'];vx,_,vy=splits['validation']
 return spec,x,y,vx,vy

def class_scores(graph,zs,y,idx=None):
 """Train score[c] uses representation under Z_c and center learned from class c
 on the same reference Train, even for origins whose label differs from c.
 """
 n=graph.n;idx=np.arange(n) if idx is None else idx
 scores=[];centers=[];radii=[]
 for c in range(graph.k):
  reps=graph.center_train(zs[c],idx,return_all=True)
  cen=reps[torch.as_tensor(y[idx]==c)].mean(dim=0)
  score=1-jsd(reps,cen)/LN2
  scores.append(score)
  centers.append(cen)
  radii.append(jsd(reps[torch.as_tensor(y[idx]==c)],cen).mean())
 return torch.stack(scores,dim=1),torch.stack(centers),torch.stack(radii)

def class_val_scores(graph,zs,centers):
 with torch.no_grad():
  return torch.stack([1-jsd(graph.evaluate_val(zs[c]),centers[c])/LN2 for c in range(graph.k)],dim=1)

def margin_from_scores(scores,y):
 y=torch.as_tensor(y,dtype=torch.long)
 target=scores.gather(1,y[:,None]).squeeze(1)
 rival=scores.masked_fill(torch.nn.functional.one_hot(y,scores.shape[1]).bool(),-1e20).max(1).values
 return target-rival

def train_conditional(graph,y,vy,old_z,targets,steps=50,lr=.12,tau=.005):
 zs=torch.nn.Parameter(torch.zeros((graph.k,graph.d+1,graph.d),dtype=DT))
 opt=torch.optim.Adam([zs],lr=lr)
 trace=[];t0=time.perf_counter()
 def inspect(step, scores,centers,radii,loss):
  with torch.no_grad():
   val=class_val_scores(graph,zs.detach(),centers.detach())
   tr_pred=scores.detach().argmax(1).numpy();v_pred=val.argmax(1).numpy()
   margins=margin_from_scores(scores,y)
   record=dict(step=step,train_BA=balanced_acc(tr_pred,y),val_BA=balanced_acc(v_pred,vy),
     train_margin_loss=float(loss.detach()),margin_q10=float(torch.quantile(margins.detach(),.1)),
     centers=centers.detach().tolist(),radii_JS=radii.detach().tolist(),
     mean_center_JSD_to_targets=float(jsd(centers.detach(),targets).mean()),
     noise_row_start=[float(torch.softmax(zs[c,graph.d],dim=0)[[2,4]].sum()) for c in range(graph.k)])
   return record
 for step in range(steps+1):
  scores,centers,radii=class_scores(graph,zs,y)
  margin=margin_from_scores(scores,y)
  loss=bal_loss(torch.sigmoid(-margin/tau),y,graph.k)
  if step % 5==0 or step in (0,steps):
   r=inspect(step,scores,centers,radii,loss);trace.append(r)
   print('CLASS_MARGIN',step,'train',round(r['train_BA'],6),'val',round(r['val_BA'],6),'loss',round(r['train_margin_loss'],7),'sec',round(time.perf_counter()-t0,1),flush=True)
  if step==steps:break
  opt.zero_grad(set_to_none=True);loss.backward()
  if not torch.isfinite(zs.grad).all():raise RuntimeError('nonfinite gradient')
  opt.step()
  del scores,centers,radii,margin,loss
 return dict(method='3 class-hypothesis policies trained by balanced sigmoid JS-margin',meta=dict(lr=lr,tau=tau,steps=steps,beta=.4,lambda_= .8,H=12),trace=trace,
  Z=zs.detach().tolist(),time_s=time.perf_counter()-t0)

def shared_summary(graph,z,y,vy,targets):
 with torch.no_grad():
  reps=graph.center_train(z,np.arange(graph.n),return_all=True)
  cent=torch.stack([reps[torch.as_tensor(y==c)].mean(0) for c in range(graph.k)])
  train_sc=1-jsd(reps[:,None,:],cent[None,:,:])/LN2
  val_sc=1-jsd(graph.evaluate_val(z)[:,None,:],cent[None,:,:])/LN2
  tp=train_sc.argmax(1).numpy();vp=val_sc.argmax(1).numpy()
  return dict(train_BA=balanced_acc(tp,y),val_BA=balanced_acc(vp,vy),centers=cent.tolist(),
   JSD_centers_to_targets=jsd(cent,targets).tolist(),
   R_JS=float(bal_loss(jsd(reps,cent[torch.as_tensor(y,dtype=torch.long)]),y,graph.k)),
   train_pred=tp.tolist(),val_pred=vp.tolist())

def inverse_shared(graph,y,vy,target,old_z,max_steps=45,init_mu=.001):
 """Damped GN from Z=0 against all 3 target class centers jointly (six constraints)."""
 z=torch.zeros((graph.d+1,graph.d),dtype=DT,requires_grad=True)
 mu=init_mu;trace=[];t0=time.perf_counter();cnt=np.asarray([np.flatnonzero(y==c) for c in range(graph.k)],dtype=object)
 centers_idx=[torch.as_tensor(np.flatnonzero(y==c),dtype=torch.long) for c in range(graph.k)]
 targetu=target[:,:graph.k-1].reshape(-1)
 for it in range(max_steps+1):
  reps=graph.center_train(z,np.arange(graph.n),return_all=True)
  centers=torch.stack([reps[idx].mean(0) for idx in centers_idx])
  loss=jsd(centers,target).mean()
  err=(targetu-centers[:,:graph.k-1].reshape(-1)).detach()
  norm=float(torch.linalg.norm(err))
  trace.append(dict(step=it,mean_JSD=float(loss.detach()),center_L2=norm,centers=centers.detach().tolist(),mu=mu))
  if it%5==0 or norm<1e-5:print('SHARED_INV',it,'L2',round(norm,9),'JS',round(float(loss.detach()),12),'sec',round(time.perf_counter()-t0,1),flush=True)
  if norm<1e-6 or it==max_steps:break
  J=torch.stack([torch.autograd.grad(centers[c,j],z,retain_graph=(c* (graph.k-1)+j <graph.k*(graph.k-1)-1))[0].flatten() for c in range(graph.k) for j in range(graph.k-1)]).detach()
  d=J.T@torch.linalg.solve(J@J.T+mu*torch.eye(len(err),dtype=DT),err)
  accepted=False
  for step_scale in [1.,.5,.25,.125,.0625,.03125]:
   trial=z.detach()+step_scale*d.reshape(z.shape)
   trial=trial-trial.mean(dim=1,keepdim=True)
   with torch.no_grad():
    trial_repr=graph.center_train(trial,np.arange(graph.n),return_all=True)
    tc=torch.stack([trial_repr[idx].mean(0) for idx in centers_idx]);new=float(jsd(tc,target).mean())
   if new<float(loss.detach())-1e-15:
    z=trial.detach().requires_grad_(True);mu=max(1e-8,mu/3);accepted=True;break
  if not accepted:
   mu*=10
   if mu>1e4:break
 with torch.no_grad():
  summary=shared_summary(graph,z,y,vy,target)
  teacher=shared_summary(graph,old_z,y,vy,target)
  row_centered=lambda a:a-a.mean(-1,keepdim=True)
  zdist=float(torch.linalg.norm(row_centered(old_z)-row_centered(z)))
 return dict(method='one shared Z inverse all margin centers simultaneously',trace=trace,Z=z.detach().tolist(),summary=summary,
   teacher=teacher,Z_difference_row_centered_Frobenius=zdist,time_s=time.perf_counter()-t0)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--task',choices=['both','conditional','inverse'],default='both');p.add_argument('--steps',type=int,default=50);p.add_argument('--inv-steps',type=int,default=45);p.add_argument('--out',type=Path,default=HERE/'results.json');a=p.parse_args()
 torch.set_num_threads(1)
 spec,x,y,vx,vy=data()
 prev=json.loads((ROOT/'code/experiments/margin_training/results/full300_tau0.005.json').read_text())
 old_z=torch.as_tensor(prev['Z'],dtype=DT);targets=torch.as_tensor(prev['history'][-1]['train']['centers'],dtype=DT)
 graph=StreamGraph(x,y,spec['gamma'],vx,beta=.4,lam=.8,horizon=12)
 print('DATA',dict(n=len(y),class_counts=np.bincount(y).tolist(),nval=len(vy)),flush=True)
 print('TEACHER',shared_summary(graph,old_z,y,vy,targets)['train_BA'],flush=True)
 out=dict(config=dict(data_seed=spec['seed'],n_train=len(y),n_val=len(vy),class_counts=np.bincount(y).tolist(),
       train_protocol='leave-one-origin',validation_protocol='held-out queries using Train-only graph',
       test_used=False,training_selection_from_validation=False),margin_teacher=shared_summary(graph,old_z,y,vy,targets))
 if a.task in ('conditional','both'):
  out['conditional']=train_conditional(graph,y,vy,old_z,targets,steps=a.steps)
  a.out.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
 if a.task in ('inverse','both'):
  out['shared_inverse']=inverse_shared(graph,y,vy,targets,old_z,max_steps=a.inv_steps)
  a.out.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
 print('FINISHED SAVED',a.out,flush=True)
