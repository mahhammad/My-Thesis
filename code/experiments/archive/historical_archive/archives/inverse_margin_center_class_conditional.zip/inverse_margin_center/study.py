"""Inverse target matching on existing margin-trained centers, independent per class.
Existing margin centers are from one class-independent shared Z (tau=0.005).
Targets are guaranteed attainable by Z_c=Z_shared, used only as a witness,
NOT used as an optimization initialization.
"""
import os,sys,json,tempfile,time
from pathlib import Path
import numpy as np
import torch
HERE=Path(__file__).resolve().parent
ROOT=HERE
sys.path.insert(0,str(ROOT/'code/data_generator'))
sys.path.insert(0,str(ROOT/'code/experiments/multistep_policy_target_match'))
sys.path.insert(0,str(ROOT/'code/experiments/diag_max_full300'))
from generate import load_config,generate
from run import jsd,DT
from stream_graph import StreamGraph

def jsv(a,b):
    return float(jsd(a,b).detach())

def clean(z):
    return (z-z.mean(-1,keepdim=True)).detach()

def fit_center(graph,idx,target,c,steps=35):
    z=torch.zeros((graph.d+1,graph.d),dtype=DT,requires_grad=True)
    start=time.perf_counter()
    log=[]
    mu=.001
    targetu=target[:graph.k-1]
    for t in range(steps):
        center=graph.center_train(z,idx)
        loss=jsd(center,target)
        err=(targetu-center[:graph.k-1]).detach()
        rec={'iter':t,'JSD':float(loss.detach()),'center':center.detach().tolist(),'L2':float(torch.linalg.norm(center-target).detach()),'mu':mu}
        log.append(rec)
        if t==0 or t%5==0 or t==steps-1:
            print('CLASS',c,'STEP',t,'JS',round(rec['JSD'],11),'center',np.round(rec['center'],6).tolist(),flush=True)
        if rec['JSD']<1e-12:break
        grads=[]
        for k in range(graph.k-1):
            gg=torch.autograd.grad(center[k],z,retain_graph=(k<graph.k-2))[0]
            grads.append(gg.flatten())
        J=torch.stack(grads).detach() # [k-1, p]
        d=J.T @ torch.linalg.solve(J@J.T+mu*torch.eye(graph.k-1,dtype=DT),err)
        dz=d.reshape(z.shape)
        accepted=False
        for eta in [1.,.5,.25,.125,.0625]:
            candidate=clean(z.detach()+eta*dz)
            with torch.no_grad():
                v=graph.center_train(candidate,idx)
                new=jsv(v,target)
            if new <rec['JSD']-1e-14:
                z=candidate.detach().requires_grad_(True)
                mu=max(1e-7,mu/3)
                accepted=True
                break
        if not accepted:
            mu*=10
            if mu>100:break
    with torch.no_grad():
        v=graph.center_train(z,idx)
    return {'class':int(c),'target':target.tolist(),'recovered':v.detach().tolist(),
            'JSD':jsv(v,target),'L2':float(torch.linalg.norm(v-target)),
            'z_recovered':clean(z).tolist(),'trace':log,'time_s':time.perf_counter()-start}

def main():
    torch.set_num_threads(1)
    spec=load_config(ROOT/'code/data_generator/config.json')
    with tempfile.TemporaryDirectory() as d:
        dat=generate(spec,d)
    x,_,y=dat['train']
    val,_,vy=dat['validation']
    record=json.loads((ROOT/'code/experiments/margin_training/results/full300_tau0.005.json').read_text())
    old_z=torch.as_tensor(record['Z'],dtype=DT)
    target=torch.as_tensor(record['history'][-1]['train']['centers'],dtype=DT)
    g=StreamGraph(x,y,spec['gamma'],val,beta=.4,lam=.8,horizon=12)
    with torch.no_grad():
        teacher_centers=torch.stack([g.center_train(old_z,np.flatnonzero(y==c)) for c in range(g.k)])
        witness=[jsv(teacher_centers[c],target[c]) for c in range(g.k)]
        center_initial=torch.stack([g.center_train(torch.zeros_like(old_z),np.flatnonzero(y==c)) for c in range(g.k)])
    print('WITNESS JS',witness,flush=True)
    print('INIT JS',[jsv(center_initial[c],target[c]) for c in range(g.k)],flush=True)
    fits=[]
    for c in range(g.k):
        fits.append(fit_center(g,np.flatnonzero(y==c),target[c],c))
    with torch.no_grad():
        rec_centers=torch.as_tensor([f['recovered'] for f in fits],dtype=DT)
        shared_val=g.evaluate_val(old_z)
        shared_scores=1-jsd(shared_val[:,None,:],target[None,:,:])/np.log(2)
        pred_shared=shared_scores.argmax(dim=1).cpu().numpy()
        class_scores=[]
        for c,f in enumerate(fits):
            this_val=g.evaluate_val(torch.as_tensor(f['z_recovered'],dtype=DT))
            sc=1-jsd(this_val,rec_centers[c][None,:])/np.log(2)
            class_scores.append(sc)
        class_scores=torch.stack(class_scores,dim=1)
        pred_class=class_scores.argmax(dim=1).cpu().numpy()
        def bal(pred):return float(np.mean([np.mean(pred[vy==c]==c) for c in range(g.k)]))
        vstats={'shared_val_balanced':bal(pred_shared),'recovered_class_hypothesis_val_balanced':bal(pred_class),
                'changed_val_predictions':int((pred_shared!=pred_class).sum()),'n_val':int(len(vy))}
    print('VALIDATION',vstats,flush=True)
    output={'metadata':{'data_seed':20261102,'reference_train':300,'validation':90,'nclasses':3,
       'beta':.4,'lambda':.8,'H':12,'tau_of_margin_teacher':.005,'teacher_shared_Z':True,
       'inverse_policy':'one shared Z_c among all origins with initial label c, 3 independent class-conditioned policies',
       'optimization':'damped Jacobian correction from zero; teacher policy never as initialization; class-conditioned evaluation uses all class hypotheses'},
       'target_centers':target.tolist(),'teacher_centers_recomputed':teacher_centers.tolist(),
       'witness_JSD_by_class':witness,'initial_centers':center_initial.tolist(),
       'results':fits,'validation':vstats}
    p=ROOT/'inverse_class_conditional_results.json'
    p.write_text(json.dumps(output,ensure_ascii=False,indent=2))
    print('SAVED',p,flush=True)
if __name__=='__main__':main()
