import numpy as np,math,json
from pathlib import Path
import os
R=Path(os.environ.get('SEC411_RAW_ROOT',str(Path(__file__).resolve().parent/'raw'/'section411_standard_S_103')))/'results'

# Independent mathematical definitions on raw per-hypothesis distributions, without importing researcher code.
def kl(p,q):
 p,q=np.broadcast_arrays(p,q)
 return np.sum(np.where(p>0,p*np.log(np.divide(p,q,out=np.ones_like(p),where=p>0)),0),axis=-1)
def js(p,q):
 m=(p+q)*.5
 return .5*(kl(p,m)+kl(q,m))
def logsumexp(x):
 a=np.max(x,axis=-1,keepdims=True)
 return np.log(np.exp(x-a).sum(axis=-1))+a[...,0]
issues=[];cells=0;maxdev=0.;num_samples=0
for p in sorted(R.glob('replay_s*.json')):
 j=json.loads(p.read_text())
 for kind,rec in j['results'].items():
  centers=np.array(rec['centers'],float)
  for split,m in rec['metrics'].items():
   Q=np.array(m['hypothesis_representations'],float);y=np.array(m['true_labels'],int);N=len(y);num_samples+=N
   distances=js(Q,centers[np.newaxis,:,:]);scores=1-distances/math.log(2)
   predicted=np.argmin(distances,axis=1)
   conf=np.array([[int(np.sum((y==c)&(predicted==k))) for k in range(3)] for c in range(3)])
   own=Q[np.arange(N),y];C=centers[y]
   rjs=js(own,C);rkl=kl(own,C);rroot=np.sqrt(rjs)
   candidates=np.array(scores,copy=True);candidates[np.arange(N),y]=-np.inf
   margin=scores[np.arange(N),y]-candidates.max(1)
   sigmoid=1/(1+np.exp(np.clip(margin/.005,-700,700)))
   nll=logsumexp(scores)-scores[np.arange(N),y]
   bal=lambda v:np.mean([v[y==c].mean() for c in range(3)])
   assertions={'predictions':(predicted,np.array(m['predictions'])),'confusion':(conf,np.array(m['confusion_true_rows_pred_cols'])),'margins':(margin,np.array(m['margins'])),'BA':(bal((predicted==y).astype(float)),m['balanced_accuracy']),'Acc':(np.mean(predicted==y),m['ordinary_accuracy']),'R_KL':(bal(rkl),m['R_KL']),'R_JS':(bal(rjs),m['R_JS']),'R_sqrt_JS':(bal(rroot),m['R_sqrt_JS']),'hard_margin':(bal((margin<=0).astype(float)),m['balanced_hard_margin_error']),'sigmoid':(bal(sigmoid),m['balanced_sigmoid_margin_loss']),'sim_NLL':(bal(nll),m['balanced_JS_similarity_NLL'])}
   for field,(v,w) in assertions.items():
    delta=float(np.max(np.abs(np.asarray(v)-np.asarray(w))))
    maxdev=max(maxdev,delta)
    if delta>3e-12:issues.append({'path':str(p.name),'method':kind,'split':split,'metric':field,'delta':delta})
   cells+=1
 print(p.name,'sample predictions checked',sum(v['metrics'][s]['N'] for v in j['results'].values() for s in ('train','validation','test')))
print('INDEPENDENT_METRICS',{'cells':cells,'sample_hypotheses_checked':num_samples,'maxdeviation':maxdev,'issues':issues[:12],'issue_count':len(issues)})
