from pathlib import Path
import os
import json, math, numpy as np
root=Path(os.environ.get('SEC411_RAW_ROOT',str(Path(__file__).resolve().parent/'raw'/'section411_standard_S_103')));s=json.loads((root/'results/SEC411_STANDARD_S_103_SUMMARY.json').read_text())

def e(t):
 if t==0 or t==1:return 0.
 return -t*math.log(t)-(1-t)*math.log1p(-t)
def js_ber(p,q):return e((p+q)*.5)-.5*(e(p)+e(q))
def bound(L,U,T):
 gaps=np.maximum(L-T,T-U)
 js=np.zeros((3,3))
 for c in range(3):
  for k in range(3):
   t=T[c,k];nearest=min(max(t,L[c,k]),U[c,k]);js[c,k]=js_ber(t,nearest)
 per=js.max(axis=1)
 return float(per.mean()),per.tolist(),float(np.maximum(gaps,0).max()),tuple(map(int,np.unravel_index(int(np.argmax(gaps)),gaps.shape)))
errors=[]
for check in s['precision_checks']:
 seed,n=check['seed'],check['n'];q=json.loads((root/f'checks/precision_s{seed}_n{n}_H12.json').read_text());f=json.loads((root/f'results/bounds_s{seed}_n{n}_H12_b0p4_l0p8.json').read_text());L=np.array(q['lower_center_enclosure']);U=np.array(q['upper_center_enclosure'])
 for name,original in f['targets'].items():
  t=np.array(original['target']);score,per,gap,arg=bound(L,U,t)
  listed=check['JSD_lower_from_conservative_enclosure'][name]['balanced_mean_JSD_lower_bound']
  if abs(score-listed)>1e-12:errors.append((seed,n,name,score,listed))
  print(seed,n,name,'max_gap',format(gap,'.10g'),'arg',arg,'conditional lower JSD',format(score,'.12g'),'perclass',[round(v,8) for v in per])
print('BINARY_JSD_CHECK',{'rows':8,'errors':errors})
