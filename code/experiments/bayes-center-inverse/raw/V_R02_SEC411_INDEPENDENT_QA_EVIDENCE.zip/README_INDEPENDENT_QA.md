# SEC411 Independent Science Audit — Reproducibility Bundle

Mission: V-R02-SEC411-S103-INDEPENDENT-QA-01
Baseline: Three generator seeds (20261102/03/04); 150/300 nested per seed; H12 beta=.4 lambda=.8 (certificate domain only).
Scope: D10 Bayes (six fixed binary64 targets) and D11 equal/bounded_equal (one 300-sample graph, seed 20261102).

## Reproduce (Python 3.11+; numpy required for directed Bellman; PyTorch required ONLY for optional solver Jacobian smoke check)

Unzip the included `raw_source_zip_SHA742b3824.zip` to directory `raw/` here, preserving its single top-level `section411_standard_S_103`.

    export SEC411_RAW_ROOT="$PWD/raw/section411_standard_S_103"
    export SEC411_AUDIT_OUT="$PWD"
    python independent_tiny_bellman.py
    python independent_archive_data.py
    python independent_solver_sanity.py
    python independent_replay_metrics.py
    python independent_cert_formula.py
    python rigorous_directed_bellman.py 20261102 150
    python rigorous_directed_bellman.py 20261102 300
    # repeat (20261103,150/300) and (20261104,150/300)

The directed calculation never imports frozen_v2 Bellman or src/precision_verify. It uses directed Decimal.exp interval evaluation, exact Fraction alpha and E=1e-8 per-positive-float-operation enlargement to bound six frozen graphs. It is CONDITIONAL on stated IEEE754/Decimal arithmetic contract and the explicit input-domain checks in the proof and code, NOT a universal proof for any graph or exact real-valued generator parameters. The archived 4ULP/EPS=1e-10 implementation is not independently formally proven for arbitrary inputs.

For categorical exclusions, use the positive rational/Pinsker JSD lower bounds from INDEPENDENT_NUMERIC_PROOF_FA.md, not floating math.log as a formal lower bound. All submitted old raw files remain immutable. No new experiment/solver is scheduled by this bundle.

The original raw ZIP SHA256: 742b38249fccf904fc5bf6e783a4110853a1a7051433f7b32c1774493f4
The independent source and six reference output JSON files are in this archive, each source to be hashed against a local manifest.

## Acceptance / future 168-run work

The eight exclusions in the report refer only to frozen stored binary64 targets in six H12 baseline contexts, with the arithmetic assumptions and positive outward gaps documented. In particular, an analytic exact-real Bayes posterior defined with ideal decimal coefficients is **not** covered until its own posterior computation error is bounded. The 48 non-baseline H/beta/lambda settings are numerical sensitivity results, not certified impossibility proofs. No part of this report by itself grants validity to the next 168 jobs; those must be separately registered and QA checked.

The bundled independent_pinsker_fraction.py recomputes each JSD lower bound as an **exact Fraction** of float endpoints and target values; only the printed decimal representation is rounded down.
