"""Recompute certified Pinsker lower bound from binary64 endpoints with exact rationals.

For each class, take largest coordinate exclusion gap delta_c=max_k [Lck-Tck,Tck-Uck,0],
then JSD_balanced >= (sum_c delta_c^2)/6 (nats).
Uses Fraction.from_float, Decimal ROUND_FLOOR only for decimal printing.
"""
from pathlib import Path
from fractions import Fraction
from decimal import Decimal, Context, ROUND_FLOOR
import json

HERE=Path(__file__).resolve().parent
TO_DEC=Context(prec=70,rounding=ROUND_FLOOR)
ROWS=[]
for path in sorted(HERE.glob('directed_baseline_*.json')):
    item=json.loads(path.read_text(encoding='utf-8'))
    L=[[Fraction.from_float(float(x)) for x in row] for row in item['lower']]
    U=[[Fraction.from_float(float(x)) for x in row] for row in item['upper']]
    for target_name, record in item['targets'].items():
        # These stored decimal strings arose from literal binary64 target arrays in source raw.
        raw=HERE/'raw'/'section411_standard_S_103'/'results'/(
            f"bounds_s{item['seed']}_n{item['n']}_H12_b0p4_l0p8.json")
        raw_doc=json.loads(raw.read_text(encoding='utf-8'))
        vals=raw_doc['targets'][target_name]['target']
        T=[[Fraction.from_float(float(x)) for x in row] for row in vals]
        delta=[max([Fraction(0)]+[L[c][k]-T[c][k] for k in range(3)]+
                   [T[c][k]-U[c][k] for k in range(3)]) for c in range(3)]
        bound=sum(x*x for x in delta)/6
        d=TO_DEC.divide(Decimal(bound.numerator),Decimal(bound.denominator))
        ROWS.append({'seed':item['seed'],'n':item['n'],'target':target_name,
                     'delta_class_outward_float':[float(x) for x in delta],
                     'rigorous_jsd_mean_lower_decimal_floor':str(d),
                     'strictly_positive_exact':bound>0})
        if not bound>0:raise AssertionError('Nonpositive Pinsker lower bound')
        print('FRACTION_PIN_SKER', item['seed'],item['n'],target_name,'exact_rational_positive',bound>0,'lower_decimal',d)
out=HERE/'independent_pinsker_certificates.json'
out.write_text(json.dumps(ROWS,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
assert len(ROWS)==8
