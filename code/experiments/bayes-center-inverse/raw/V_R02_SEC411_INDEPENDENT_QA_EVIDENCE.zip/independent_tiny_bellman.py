"""Independent path-enumeration / recursion oracle for Bellman necessary bounds.
No calls to archive tests or source kernel inside oracle. V2 imported ONLY after oracle outputs.
"""
import sys, math, itertools, numpy as np, json
from functools import lru_cache
from pathlib import Path
import os
SRC=Path(os.environ.get('SEC411_RAW_ROOT',str(Path(__file__).resolve().parent/'raw'/'section411_standard_S_103')))/'src'/'frozen_v2'
sys.path.insert(0,str(SRC))
from exact_origin_excluded_bound import exact_origin_excluded_center_bounds

def alpha_formula(beta,lam,H):
 a=[]
 for t in range(1,H+1):
  v=0
  for length in range(t,H+1):
   p=beta*((1-beta)**(length-1)) if length<H else (1-beta)**(H-1)
   v+=p*lam**(t-1)/sum(lam**j for j in range(length))
  a.append(v)
 return np.array(a)

def independent_B(x,gamma):
 n,d=x.shape
 B={}
 for i in range(n):
  for b in range(d):
   if not np.isfinite(x[i,b]):continue
   weights={j:math.exp(-gamma[b]*(x[i,b]-x[j,b])**2) for j in range(n) if j!=i and np.isfinite(x[j,b])}
   wsum=sum(weights.values())
   if wsum>0:B[i,b]={j:w/wsum for j,w in weights.items()}
 return B

def explicit_dp(x,y,gamma,alpha):
 n,d=x.shape;K=max(y)+1;B=independent_B(x,gamma);H=len(alpha)
 perL=np.zeros((n,K));perU=np.zeros((n,K))
 for o in range(n):
  for c in range(K):
   def solve(maximize):
    @lru_cache(None)
    def F(t,i,b):
     reward=alpha[t-1]*(int(y[i]==c))
     if t==H:return reward
     options=[]
     for a in range(d):
      current=B.get((i,a),{})
      z={j:v for j,v in current.items() if j!=o}
      den=sum(z.values())
      if den>0:options.append(sum(p*F(t+1,j,a) for j,p in z.items())/den)
     if not options:raise RuntimeError('deadend')
     return reward+(max(options) if maximize else min(options))
    first=[]
    for b in range(d):
     if (o,b) not in B:continue
     first.append(sum(prob*F(1,j,b) for j,prob in B[o,b].items()))
    return max(first) if maximize else min(first)
   perL[o,c]=solve(False);perU[o,c]=solve(True)
 centerL=np.stack([perL[y==c].mean(0) for c in range(K)])
 centerU=np.stack([perU[y==c].mean(0) for c in range(K)])
 return perL,perU,centerL,centerU

def explicit_fixed(x,y,gamma,alpha,z,origin):
 n,d=x.shape;K=int(y.max())+1;B=independent_B(x,gamma)
 def soft(p,actions):
  v=np.array([p[a] for a in actions]); v-=v.max();v=np.exp(v);v/=v.sum();return dict(zip(actions,v))
 actions=[b for b in range(d) if (origin,b) in B]
 p0=soft(z[d],actions)
 states={(i,b):p0[b]*p for b in actions for i,p in B[origin,b].items()}
 outcome=np.zeros(K)
 for t,weight in enumerate(alpha):
  for (i,b),prob in states.items(): outcome[y[i]]+=weight*prob
  if t==len(alpha)-1:break
  nxt={}
  for (i,b),mass in states.items():
   actions=[]; dist={}
   for a in range(d):
    sub={j:p for j,p in B.get((i,a),{}).items() if j!=origin}
    dsum=sum(sub.values())
    if dsum:
     actions.append(a);dist[a]={j:p/dsum for j,p in sub.items()}
   for a,choose in soft(z[b],actions).items():
    for j,p in dist[a].items():nxt[j,a]=nxt.get((j,a),0.)+mass*choose*p
  states=nxt
 if abs(outcome.sum()-1)>5e-13:raise Exception(('mass',outcome))
 return outcome

cases=[
 ('counterexample',np.array([[0.],[0.],[math.sqrt(math.log(4))]]),np.array([0,0,1]),np.array([1.]),2),
 ('masked3',np.array([[0.,1.,np.nan],[.1,np.nan,.3],[.3,.5,.2],[.4,.2,np.nan],[np.nan,.8,.5],[.8,.7,.2]]),np.array([0,1,2,0,1,2]),np.array([1.,.5,2.]),3),
 ('mixed4',np.array([[0.,.1],[.9,.4],[.4,.8],[.1,np.nan],[.5,.3]]),np.array([0,1,2,1,0]),np.array([.8,1.3]),4),
 ('H1',np.array([[0.],[.2],[1.],[1.2]]),np.array([0,1,2,1]),np.array([1.2]),1),
]
error=[];fixed=0
rng=np.random.default_rng(20261114)
for name,x,y,g,H in cases:
 a=alpha_formula(.4,.8,H)
 low,high,L,U=explicit_dp(x,y,g,a)
 v2=exact_origin_excluded_center_bounds(x,y,g,a,return_per_origin=True)
 checks=[('perlower',np.array(v2['lower_per_origin']),low),('perupper',np.array(v2['upper_per_origin']),high),('centerlower',np.array(v2['lower_center_probabilities']),L),('centerupper',np.array(v2['upper_center_probabilities']),U)]
 for label,given,want in checks:
  delta=float(np.abs(given-want).max());
  if delta>1e-12:error.append((name,label,delta))
 for _ in range(10):
  z=rng.normal(size=(x.shape[1]+1,x.shape[1]))
  for origin in range(len(x)):
   result=explicit_fixed(x,y,g,a,z,origin);fixed+=1
   if not (np.all(result>=low[origin]-1e-12) and np.all(result<=high[origin]+1e-12)):error.append((name,'fixed-policy outside',origin,result,low[origin],high[origin]))
 print(name,'n',len(x),'H',H,'max discrepancies',[float(np.abs(given-want).max()) for _,given,want in checks], 'center interval',U-L)
 if name=='counterexample':print('regression origin-0 c1',low[0,1],high[0,1],'center',L[0,1])
print('INDEPENDENT_ORACLE',json.dumps({'cases':len(cases),'per_origin_fixed_policies_checked':fixed,'errors':list(map(str,error[:10])),'pass':not bool(error)}))
