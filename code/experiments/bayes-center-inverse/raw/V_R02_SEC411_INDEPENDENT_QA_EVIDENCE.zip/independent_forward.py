"""Direct independent forward recurrence, no import from researcher Graph/Replayer.
Sample-specific no return, same-class policies loaded from immutable raw JSON.
"""
from pathlib import Path
import os
import numpy as np,json,math,time
ROOT=Path(os.environ.get('SEC411_RAW_ROOT',str(Path(__file__).resolve().parent/'raw'/'section411_standard_S_103')))
G=np.array([.8,1.2,.5,1.,.6]);A=np.array([.6566475879241669, .20531807033933358, .07892112293813353, .032920504907883875, .014348111243380264, .006425261008031199, .002930095457478824, .001353600793510958, .00063, .0002929, .000137, .000065]) # will overwrite with frozen exact

def policy(z,valid):
 inds=np.flatnonzero(valid)
 if not len(inds):return np.zeros(len(z))
 a=np.asarray(z)[inds];e=np.exp(a-a.max());out=np.zeros(len(z));out[inds]=e/e.sum();return out

def compute_kernel(x):
 n,d=x.shape;out=np.zeros((d,n,n),float)
 for b in range(d):
  finite=np.isfinite(x[:,b]);v=np.where(finite,x[:,b],0.)
  scores=np.exp(-G[b]*(v[:,None]-v[None,:])**2)
  scores*=finite[:,None]&finite[None,:]
  scores[np.arange(n),np.arange(n)]=0
  rows=scores.sum(1);out[b]=np.divide(scores,rows[:,None],out=np.zeros_like(scores),where=rows[:,None]>0)
 return out

def direct_walk_at_origin(x,y,B,alpha,z,origin):
 n,d=x.shape;k=3
 legal=np.zeros((n,d),dtype=bool);den=np.zeros((n,d))
 for b in range(d):
  den[:,b]=np.sum(B[b],axis=1)-B[b,:,origin]
 legal=den>1e-12
 start=policy(z[d],np.isfinite(x[origin]))
 state=np.stack([start[b]*B[b,origin,:] for b in range(d)],axis=1)
 out=np.zeros(k)
 for t,coefficient in enumerate(alpha):
  out+=coefficient*np.bincount(y,weights=state.sum(1),minlength=k)
  if t==len(alpha)-1:break
  choices=np.zeros((n,d))
  for node in range(n):
   for prev_b in range(d):
    if state[node,prev_b]:choices[node]+=state[node,prev_b]*policy(z[prev_b],legal[node])
  nxt=np.zeros((n,d))
  for b in range(d):
   normalized=np.divide(choices[:,b],den[:,b],out=np.zeros(n),where=legal[:,b]);nxt[:,b]=normalized@B[b]
  nxt[origin,:]=0
  state=nxt
 return out

def main(seed,n,limit_per_class=None):
 dat=np.load(ROOT/f'data/train_{seed}.npz');yall=dat['y'];ref=np.arange(300) if n==300 else None
 if ref is None:
  seeds={20261102:20261201,20261103:20261202,20261104:20261203};rng=np.random.default_rng(seeds[seed]);ref=np.concatenate([rng.choice(np.flatnonzero(yall==c),50,replace=False) for c in range(3)]);rng.shuffle(ref)
 x=dat['x'][ref];y=yall[ref]
 B=compute_kernel(x)
 alpha=np.asarray(json.loads((ROOT/f'results/bounds_s{seed}_n{n}_H12_b0p4_l0p8.json').read_text())['alpha'])
 saved=json.loads((ROOT/f'results/replay_s{seed}_n{n}.json').read_text())
 wanted=saved['results']['Bayes_target_Q100_GN30']['centers']; chosen=saved['results']['Bayes_target_Q100_GN30']['policy_selection']
 out=[];t0=time.perf_counter()
 for c in range(3):
  ini=chosen[c]['selected_initialization'];s=json.loads((ROOT/f'results/solver_s{seed}_n{n}_class{c}_{ini}.json').read_text());z=np.asarray(s['z'])
  ids=np.flatnonzero(y==c)
  if limit_per_class:ids=ids[:limit_per_class]
  vec=np.array([direct_walk_at_origin(x,y,B,alpha,z,int(o)) for o in ids]);out.append(vec.mean(0))
  archived=np.array(wanted[c]);diff=np.abs(np.asarray(out[c])-archived)
  print('forward',seed,n,c,ini,'checked origins',len(ids),'computed',out[c].tolist(),'archive',archived.tolist(),'max_diff',diff.max())
 print('time',time.perf_counter()-t0)
if __name__=='__main__':main(20261102,150)
