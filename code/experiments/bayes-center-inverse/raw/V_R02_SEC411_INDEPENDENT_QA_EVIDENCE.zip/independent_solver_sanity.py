import sys, pathlib, importlib.util, math, json, os, numpy as np
from pathlib import Path
R=pathlib.Path(os.environ.get('SEC411_RAW_ROOT',str(Path(__file__).resolve().parent/'raw'/'section411_standard_S_103')))
errs=[]; nacc=nbad=naudit=0;maxdelta=0

def JSD(p,q):
 p=np.asarray(p,float);q=np.asarray(q,float);m=(p+q)/2
 def KL(a,b):return float(np.where(a>0,a*np.log(np.divide(a,b,out=np.ones_like(a),where=a>0)),0).sum())
 return .5*(KL(p,m)+KL(q,m))
for p in sorted((R/'results').glob('solver_s*.json')):
 j=json.loads(p.read_text());ctr=np.array(j['center']);target=np.array(j['target']);value=JSD(ctr,target)
 if abs(value-j['best_exact_JSD'])>2e-12:errs.append(('center_j',p.name,value,j['best_exact_JSD']))
 vals=[j['Q_end_exact_JSD']]+[v['best_JSD'] for v in j['GN_trace']]
 if any(vals[i+1]>vals[i]+1e-12 for i in range(len(vals)-1)):errs.append(('nonmonotonic',p.name))
 if len(j['GN_trace'])!=j['GN_steps_completed'] or j['GN_steps_completed']>30 or j['Q_steps_completed']!=100:errs.append(('budget',p.name))
 nacc+=sum(x['accepted'] for x in j['GN_trace']);nbad+=sum(not x['accepted'] for x in j['GN_trace']);naudit+=1
 maxdelta=max(maxdelta,abs(value-j['best_exact_JSD']))
print('SOLVER_ARCHIVE_CHECK',{'runs':naudit,'GN_accepted_steps':nacc,'GN_rejected_steps':nbad,'max_JSD_diff':maxdelta,'errors':errs[:10]})

# Fresh tiny finite-difference Jacobian test: source autograd derivative against
# independent scalar path propagator, not against the source's torch gradient routine.
sys.path.insert(0,str(R/'src'))
spec=importlib.util.spec_from_file_location('solve',R/'src/solve_bayes.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
sys.path.insert(0,str(Path(__file__).resolve().parent))
from independent_tiny_bellman import explicit_fixed, alpha_formula
import torch
x=np.array([[0,.2],[.4,.1],[.7,.3],[.8,.2],[.2,.9],[.1,.6]],float)
y=np.array([0,1,2,0,1,2]);g=np.array([.8,1.2]);alpha=alpha_formula(.4,.8,3)
sub=mod.Graph(x,y,g,alpha).subset([0,3]);rs=np.random.default_rng(19);z=rs.normal(0,.25,(3,2))
zz=torch.tensor(z,dtype=torch.float64,requires_grad=True)
value=sub.center(zz)
Jac=torch.autograd.functional.jacobian(sub.center,zz).detach().numpy()
finite=[];param=[(0,0),(0,1),(1,0),(1,1),(2,0),(2,1)]
for a,b in param:
 plus=z.copy();minus=z.copy();h=1e-5;plus[a,b]+=h;minus[a,b]-=h
 p=np.mean([explicit_fixed(x,y,g,alpha,plus,int(i)) for i in (0,3)],axis=0)
 m=np.mean([explicit_fixed(x,y,g,alpha,minus,int(i)) for i in (0,3)],axis=0)
 finite.append((p-m)/(2*h))
fd=np.array(finite).T;comp=Jac.reshape(3,6)
print('JACOBIAN_INDEPENDENT_FINITE_DIFF',{'params':6,'output_coords':3,'max_abs_delta':float(np.abs(fd-comp).max()),'passed':bool(np.abs(fd-comp).max()<5e-8),'autograd_center':value.detach().numpy().tolist(),'explicit_center':np.mean([explicit_fixed(x,y,g,alpha,z,int(i)) for i in (0,3)],axis=0).tolist()})
