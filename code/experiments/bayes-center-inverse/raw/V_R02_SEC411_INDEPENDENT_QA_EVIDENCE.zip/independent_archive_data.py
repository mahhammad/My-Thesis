from __future__ import annotations
from pathlib import Path
import os
import hashlib, json, numpy as np, math, collections, re
ROOT=Path(os.environ.get('SEC411_RAW_ROOT',str(Path(__file__).resolve().parent/'raw'/'section411_standard_S_103')))
read=lambda p:json.loads((ROOT/p).read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=read('data/freeze_manifest.json');summary=read('results/SEC411_STANDARD_S_103_SUMMARY.json')
settings={(1,.4,.8),(2,.4,.8),(3,.4,.8),(4,.4,.8),(12,.4,.8),(12,.2,.8),(12,.7,.8),(12,.4,.4),(12,.4,1.)}
errs=[]
def ch(ok,msg):
 if not ok:errs.append(msg)
nb=ns=np_=nr=0;keys=[]
for p in ROOT.glob('results/bounds_s*.json'):
 j=json.loads(p.read_text());nb+=1;keys.append(('B',j['seed'],j['n'],j['H'],j['beta'],j['lambda']))
 ch((j['H'],j['beta'],j['lambda']) in settings,f'bound config {p.name}')
 ch(j['status']=='PASS_FLOAT64_NUMERICAL_ONLY' and j['certificate']=='NOT_VALIDATED_RIGOROUS_INTERVAL',f'bound status {p.name}')
 ch(j['source_git_blob']=='7fe3ae82f10b3120054854f82ee3916c55605f30',f'core {p.name}')
 ch(j['input']['canonical_train_sha256']==manifest['seeds'][str(j['seed'])]['canonical_train_sha256'],f'train {p.name}')
 lo=np.array(j['lower_center_probabilities']);hi=np.array(j['upper_center_probabilities']);ch(lo.shape==hi.shape==(3,3) and np.all(lo<=hi),f'bound matrix {p.name}')
 T=np.array(j['targets']['bayes']['target']);gap=np.maximum.reduce([lo-T,T-hi,np.zeros_like(T)]).max();ch(abs(gap-j['targets']['bayes']['max_raw_violation'])<1e-12,f'gap {p.name}')
for p in ROOT.glob('checks/precision_s*.json'):
 j=json.loads(p.read_text());np_+=1;keys.append(('P',j['seed'],j['n']))
 ch(j['QA']=='NEEDS_INDEPENDENT_REVIEW',f'precision conditional {p.name}')
 orig=read(j['input_bounds_path']);v1=np.array(orig['lower_center_probabilities']);v2=np.array(orig['upper_center_probabilities']);l=np.array(j['lower_center_enclosure']);u=np.array(j['upper_center_enclosure']);ch(np.all(l<=v1+1e-12) and np.all(u>=v2-1e-12),f'precision enclosure {p.name}')
 for k,d in j['target_decisions'].items():
  t=np.array(orig['targets'][k]['target']);gap=np.maximum(l-t,t-u).max();ch(abs(gap-d['max_validated_coordinate_gap'])<1e-12,f'prec gap {p.name} {k}')
for p in ROOT.glob('results/solver_s*.json'):
 j=json.loads(p.read_text());ns+=1;keys.append(('S',j['seed'],j['n'],j['class'],j['initialization']))
 ch(j['Q_steps_completed']==100 and j['GN_max_steps']==30 and j['GN_steps_completed']<=30,f'solver budget {p.name}')
 ch(j['status']=='PASS_BOUNDED_BAYES_FIT',f'solver status {p.name}')
 ch(j['source_train_sha256']==manifest['seeds'][str(j['seed'])]['canonical_train_sha256'],f'solver data {p.name}')
for p in ROOT.glob('results/replay_s*.json'):
 j=json.loads(p.read_text());nr+=1;keys.append(('R',j['seed'],j['n']))
 ch(j['status']=='PASS_INDEPENDENT_NUMPY_FORWARD_REPLAY',f'replay status {p.name}')
 for method,d in j['results'].items():
  for split,metrics in d['metrics'].items():
   conf=np.array(metrics['confusion_true_rows_pred_cols']);base=conf.diagonal()/conf.sum(1)
   ch(abs(np.mean(base)-metrics['balanced_accuracy'])<1e-12,f'BA {p.name} {method} {split}')
   ch(conf.sum()==metrics['N'],f'confusion count {p.name} {method} {split}')
   # independently reaggregate JSD and sqrt JSD per sample/class from recorded raw arrays
   y=np.asarray(metrics['true_labels']);v=np.asarray(metrics['per_sample_own_R_JS']);roots=np.asarray(metrics['per_sample_own_sqrtJS']);ch(np.max(np.abs(np.sqrt(v)-roots))<1e-12,f'sqrt sample {p.name}')
   for field,values in [('R_JS',v),('R_sqrt_JS',roots),('R_KL',np.asarray(metrics['per_sample_own_R_KL']))]:
    target=np.mean([np.mean(values[y==c]) for c in range(3)]);ch(abs(target-metrics[field])<1e-12,f'metric {field} {p.name} {method} {split}')
ch(len(keys)==len(set(keys)),f'nonunique run keys {len(keys)} {len(set(keys))}')
ch((nb,np_,ns,nr)==(54,6,36,6),f'counts {nb,np_,ns,nr}')
ch(summary['counts']['total_jobs']==103 and summary['counts']['separate_resource_probe_jobs']==1,'summary count')
# data identities, independent posterior via explicit inverse with observed-pattern Gaussian
conf= {'pi':np.array([.25,.45,.30]),'mu':np.array([[-2.,-.3,0.,-1.2,0.],[0.,.7,0.,0.,0.],[2.,-.4,0.,1.2,0.]]),'corr':np.array([[1.,.35,0.,.2,0.],[.35,1.,0.,0.,0.],[0.,0.,1.,0.,.3],[.2,0.,0.,1.,0.],[0.,0.,.3,0.,1.]]),'sd':np.array([.95,1.,1.2,.95,1.1])}
for seed in (20261102,20261103,20261104):
 m=manifest['seeds'][str(seed)];d=np.load(ROOT/f'data/train_{seed}.npz');x=d['x'];mask=d['mask'];y=d['y'];ch((x.shape,y.shape)==((300,5),(300,)),f'data shape {seed}');ch(np.array_equal(mask,np.isfinite(x)),f'mask {seed}')
 c=np.array(x,dtype='<f8',copy=True);c[~mask]=np.nan
 ch(sha(c.tobytes())==m['array_sha256']['X'],f'X sha {seed}')
 ch(sha(np.ascontiguousarray(y,dtype='<i8').tobytes())==m['array_sha256']['y'],f'y sha {seed}')
 ch(sha(np.ascontiguousarray(mask,dtype='u1').tobytes())==m['array_sha256']['mask'],f'mask sha {seed}')
 for split,N in [('validation',90),('test',120)]:
  v=np.load(ROOT/f'data/{split}_{seed}.npz');ch(v['x'].shape==(N,5) and v['y'].shape==(N,),f'split {split} {seed}')
 # independent posterior formula using inverse and slogdet (no generator imports)
 logp=np.tile(np.log(conf['pi']),(300,1));post=np.empty((300,3));cov=np.diag(conf['sd'])@conf['corr']@np.diag(conf['sd'])
 for i,row in enumerate(x):
  ix=np.flatnonzero(np.isfinite(row));sigma=cov[np.ix_(ix,ix)];sign,logdet=np.linalg.slogdet(sigma);inv=np.linalg.inv(sigma)
  for cl in range(3):
   residual=row[ix]-conf['mu'][cl,ix]
   logp[i,cl] -= .5*(residual@inv@residual + logdet + len(ix)*np.log(2*np.pi))
 p=np.exp(logp-logp.max(axis=1,keepdims=True));p/=p.sum(axis=1,keepdims=True)
 recorded=np.load(ROOT/f'data/bayes_posterior_train_{seed}.npy');ch(np.max(np.abs(p-recorded))<3e-14,f'posterior {seed} err={np.max(np.abs(p-recorded))}')
 target=np.stack([p[y==cl].mean(0) for cl in range(3)]);r=np.load(ROOT/f'data/bayes_target_{seed}.npy');ch(np.max(np.abs(target-r))<5e-15,f'Bayes target {seed}')
 # independent (same stipulated RNG algorithm) 150 selection, verify IDs match published bound row hash
 refseeds={20261102:20261201,20261103:20261202,20261104:20261203};rng=np.random.default_rng(refseeds[seed]);ix=np.concatenate([rng.choice(np.flatnonzero(y==cl),50,replace=False) for cl in range(3)]);rng.shuffle(ix)
 ch(len(np.unique(ix))==150 and (np.bincount(y[ix],minlength=3)==50).all(),f'n150 {seed}')
 a=read(f'results/bounds_s{seed}_n150_H12_b0p4_l0p8.json');ch(sha(ix.astype('<i8').tobytes())==a['ids_sha256'],f'n150 SHA {seed}')
 print('DATA',seed,'counts',np.bincount(y).tolist(),'max posterior error',float(np.max(np.abs(p-recorded))),'max bayes error',float(np.max(np.abs(target-r))),'target',target.tolist())
print('RUN_COUNTS',{'bounds':nb,'precision':np_,'solver':ns,'replay':nr,'resource_probe':1,'unique_ids':len(set(keys))})
print('ERRORS',len(errs),errs[:30]);json.dump({'counts':[nb,np_,ns,nr,1],'uniq':len(set(keys)),'errors':errs},open(Path(os.environ.get('SEC411_AUDIT_OUT',str(Path(__file__).resolve().parent)))/'archive_data_checks.json','w'),indent=2)
