"""INDEPENDENT D10/D11 baseline directed-decimal + outward binary64 Bellman bounds.

No import from R02 candidate/proof code. Input original arrays and mathematical alpha only.
Kernel weights use exact Decimal.from_float(x/gamma) inputs and guaranteed
outward intervals via Decimal correctly rounded exp + one decimal predecessor/
successor; all other decimal operations ROUND_FLOOR/CEILING. Fraction computes
alpha exactly for binary64 input parameters. Binary64 nonnegative dot/sums are
outward padded by E=1e-8, which exceeds gamma_{2n+2} (<7e-14 for n<=300).

CERTIFICATE ASSUMPTIONS: IEEE754 correctly rounded basic +,-,*,/; Decimal.exp
correctly rounded at specified precision; no nonzero subnormal contributions;
no FTZ/DAZ; n<=300; all x/gamma finite frozen binary64; legal mask stable.
This implementation *checks* input scale, number of legal targets per class and
min denominators; it refuses outside the six intended baseline contexts.
"""
from pathlib import Path
import os
from decimal import Decimal, Context, localcontext, ROUND_FLOOR, ROUND_CEILING, ROUND_HALF_EVEN
from fractions import Fraction
import numpy as np, json, hashlib, math, time, sys
R=Path(os.environ.get('SEC411_RAW_ROOT',str(Path(__file__).resolve().parent/'raw'/'section411_standard_S_103')))
PREC=80
CTXL=Context(prec=PREC, rounding=ROUND_FLOOR)
CTXU=Context(prec=PREC, rounding=ROUND_CEILING)
CTXN=Context(prec=PREC, rounding=ROUND_HALF_EVEN)
E=1e-8
ZERO=Decimal(0)

# Independently compare exact Decimal to exact binary64 float to move outward.
def float_bound(v,side):
 f=float(v)
 if not math.isfinite(f):raise ArithmeticError('unbounded numeric conversion')
 exact=Decimal.from_float(f)
 if side=='lo':
  while exact>v:
   f=float(np.nextafter(f,-np.inf)); exact=Decimal.from_float(f)
 else:
  while exact<v:
   f=float(np.nextafter(f,np.inf)); exact=Decimal.from_float(f)
 return f

def decimal_kernel_interval(x,gamma):
 n,d=x.shape;Blo=np.zeros((d,n,n),float);Bhi=np.zeros_like(Blo)
 if max(np.abs(x[np.isfinite(x)]))>5 or n>300 or n<3:raise ArithmeticError('outside scoped data range')
 if np.max(gamma)>1.2+1e-15 or np.min(gamma)<0.5:raise ArithmeticError('outside scoped gamma range')
 for b in range(d):
  good=np.flatnonzero(np.isfinite(x[:,b]));Dec=[Decimal.from_float(float(x[i,b])) if np.isfinite(x[i,b]) else None for i in range(n)];g=Decimal.from_float(float(gamma[b]))
  Wlo=[[ZERO for j in range(n)] for i in range(n)];Whi=[[ZERO for j in range(n)] for i in range(n)]
  for ii,i in enumerate(good):
   for j in good[ii+1:]:
    delta=CTXN.subtract(Dec[i],Dec[j])
    # Correctly rounded floor/ceiling for nonnegative gamma*(difference)^2.
    sqlo=CTXL.multiply(delta,delta);sqhi=CTXU.multiply(delta,delta)
    tlo=CTXL.multiply(g,sqlo);thi=CTXU.multiply(g,sqhi)
    if thi>Decimal(68):raise ArithmeticError('exponent outside demonstrated normal-range proof')
    with localcontext(CTXN):
     # exp is documented correctly rounded ROUND_HALF_EVEN for Python decimal.
     l=(-thi).exp().next_minus()
     u=(-tlo).exp().next_plus()
    if l<=0 or u<=0 or l>u:raise ArithmeticError('exponential interval')
    Wlo[i][j]=Wlo[j][i]=l
    Whi[i][j]=Whi[j][i]=u
  for i in good:
   dl=ZERO;du=ZERO
   for j in good:
    dl=CTXL.add(dl,Wlo[i][j]);du=CTXU.add(du,Whi[i][j])
   if dl<=0:raise ArithmeticError('zero denominator')
   for j in good:
    if i==j:continue
    Blo[b,i,j]=float_bound(CTXL.divide(Wlo[i][j],du),'lo')
    Bhi[b,i,j]=float_bound(CTXU.divide(Whi[i][j],dl),'hi')
 return Blo,Bhi

def alpha_exact_interval(beta,lam,H):
 bet=Fraction.from_float(float(beta));lam=Fraction.from_float(float(lam));alpha=[Fraction(0) for _ in range(H)]
 for ell in range(1,H+1):
  prob=bet*(1-bet)**(ell-1) if ell<H else (1-bet)**(H-1)
  den=sum((lam**t for t in range(ell)),Fraction(0))
  for t in range(ell):alpha[t]+=prob*lam**t/den
 if sum(alpha)!=1:raise ArithmeticError('alpha does not normalize exactly')
 lower=[];upper=[]
 for a in alpha:
  x=float(a);lo=x;hi=x
  while Fraction.from_float(lo)>a:lo=float(np.nextafter(lo,-np.inf))
  while Fraction.from_float(hi)<a:hi=float(np.nextafter(hi,np.inf))
  lower.append(lo);upper.append(hi)
 return np.array(lower),np.array(upper)

def dn(x):return np.maximum(0.0,np.nextafter(np.asarray(x)*np.float64(1-E),-np.inf))
def up(x):return np.nextafter(np.asarray(x)*np.float64(1+E),np.inf)

def independent_interval(x,y,gamma,H=12,beta=.4,lam=.8):
 n,d=x.shape;K=int(max(y))+1;start=time.perf_counter()
 B0,B1=decimal_kernel_interval(x,gamma);ker_wall=time.perf_counter()-start
 al,au=alpha_exact_interval(beta,lam,H)
 perlo=np.empty((n,K));perhi=np.empty((n,K));denmin=1.0
 for o in range(n):
  # Explicit exclusion by sum of slices, not subtract-from-total.
  D0=np.empty((n,d));D1=np.empty((n,d))
  for b in range(d):
   D0[:,b]=np.sum(B0[b,:,:o],axis=1)+np.sum(B0[b,:,o+1:],axis=1)
   D1[:,b]=np.sum(B1[b,:,:o],axis=1)+np.sum(B1[b,:,o+1:],axis=1)
  Dl=dn(np.maximum(0,D0));Du=up(D1)
  valid=Dl>1e-12;possible=Du>1e-12
  if not np.array_equal(valid,possible) or not valid.any(axis=1).all():raise ArithmeticError('ambiguous legal mask')
  denmin=min(denmin,float(Dl[valid].min()))
  startmask=np.isfinite(x[o]);
  for c in range(K):
   reward=(y==c).astype(float)
   low=np.broadcast_to(al[H-1]*reward[:,None],(n,d)).copy()
   high=np.broadcast_to(au[H-1]*reward[:,None],(n,d)).copy()
   for t in range(H-2,-1,-1):
    low[o,:]=0.;high[o,:]=0.
    # Nonnegative contraction, exact origin excluded by zero value at origin.
    nl=np.einsum('bij,jb->ib',B0,low,optimize=True)
    nu=np.einsum('bij,jb->ib',B1,high,optimize=True)
    nl=dn(np.maximum(0,nl));nu=up(nu)
    ql=np.divide(nl,Du,out=np.zeros_like(nl),where=valid)
    qu=np.divide(nu,Dl,out=np.zeros_like(nu),where=valid)
    ql=dn(ql);qu=up(qu)
    optl=np.min(np.where(valid,ql,np.inf),axis=1)
    optu=np.max(np.where(valid,qu,-np.inf),axis=1)
    optl[o]=0.;optu[o]=0.
    low=np.broadcast_to(dn(al[t]*reward+optl)[:,None],(n,d)).copy()
    high=np.broadcast_to(up(au[t]*reward+optu)[:,None],(n,d)).copy()
   firstl=np.einsum('bj,jb->b',B0[:,o,:],low,optimize=True)
   firstu=np.einsum('bj,jb->b',B1[:,o,:],high,optimize=True)
   perlo[o,c]=float(np.min(dn(np.maximum(0,firstl[startmask]))))
   perhi[o,c]=float(np.max(up(firstu[startmask])))
 lower=np.array([dn(perlo[y==c].mean(axis=0)) for c in range(K)])
 upper=np.array([up(perhi[y==c].mean(axis=0)) for c in range(K)])
 return lower,upper,dict(kernel_wall_s=ker_wall,total_wall_s=time.perf_counter()-start,denmin=denmin,E=E,decimal_precision=PREC)

def binary_js(p,q):
 def h(x):
  return 0 if x in (0,1) else -x*math.log(x)-(1-x)*math.log1p(-x)
 return h((p+q)/2)-(h(p)+h(q))/2

def main(seed,n):
 frozen=json.loads((R/'data/freeze_manifest.json').read_text())['seeds'][str(seed)]
 train=np.load(R/f'data/train_{seed}.npz');X=train['x'];Y=train['y']
 if n==150:
  ref={20261102:20261201,20261103:20261202,20261104:20261203};rng=np.random.default_rng(ref[seed]);ids=np.concatenate([rng.choice(np.flatnonzero(Y==c),50,replace=False) for c in range(3)]);rng.shuffle(ids)
 else:ids=np.arange(300)
 x=X[ids];y=Y[ids]
 gamma=np.array([.8,1.2,.5,1.,.6]);L,U,diagnostic=independent_interval(x,y,gamma)
 P=json.loads((R/f'checks/precision_s{seed}_n{n}_H12.json').read_text()); A=np.array(P['lower_center_enclosure']); B=np.array(P['upper_center_enclosure']);
 bd=json.loads((R/f'results/bounds_s{seed}_n{n}_H12_b0p4_l0p8.json').read_text());
 result={'seed':seed,'n':n,'H':12,'beta':.4,'lambda':.8,'independent_method':'directed_decimal_exp_fraction_exact_alpha_float64_expansion_eps_1e-8','observations':diagnostic,'lower':L.tolist(),'upper':U.tolist(),'older_decimal_lower_enclosed':bool(np.all(L<=A+1e-14)),'older_decimal_upper_enclosed':bool(np.all(U>=B-1e-14)),'candidate_float_lower_enclosed':bool(np.all(L<=np.array(bd['lower_center_probabilities'])+1e-14)),'candidate_float_upper_enclosed':bool(np.all(U>=np.array(bd['upper_center_probabilities'])-1e-14)),'targets':{}}
 for name,t in bd['targets'].items():
  T=np.array(t['target']);dist=np.maximum(L-T,T-U);maxgap=float(np.max(dist));cond=[]
  for c in range(3):
   cond.append(max(binary_js(T[c,k],min(max(T[c,k],L[c,k]),U[c,k])) for k in range(3)))
  result['targets'][name]={'max_coordinate_exclusion':maxgap,'balanced_binary_JSD_lower':float(np.mean(cond))}
 print('DIRECTED_BASELINE_CHECK',seed,n,'kernel',round(diagnostic['kernel_wall_s'],2),'wall',round(diagnostic['total_wall_s'],2),'denmin',diagnostic['denmin'],'old_bracket',result['older_decimal_lower_enclosed'],result['older_decimal_upper_enclosed'],'targets',result['targets'],flush=True)
 out=Path(os.environ.get('SEC411_AUDIT_OUT',str(Path(__file__).resolve().parent)))/f'directed_baseline_{seed}_{n}.json';out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 return result
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('seed',type=int);p.add_argument('n',type=int);a=p.parse_args();main(a.seed,a.n)
