"""Bayes external target fitting: class-conditioned 6x5 masked-Z Q warm + damped GN.

No archival bound and no Test labels used. Exact origin-excluded center forward.
Pre-registered max budgets: Q Adam 100, damped GN 30, two inits 0/random.
CPU single-thread, all results immutable, fail-closed. Distances are JSD nats.
"""
import argparse,json,hashlib,os,sys,time,resource
from pathlib import Path
import numpy as np
import torch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src/frozen_v2'))
from exact_origin_excluded_bound import shared_feature_kernel
from generate_frozen import spec,sha
from bounds_run import subset150,alpha_from_project
DT=torch.float64
torch.set_num_threads(1)

def jsd(p,q):
    m=.5*(p+q)
    def ent(v):
        return -(torch.where(v>0,v*torch.log(v.clamp_min(1e-300)),torch.zeros_like(v))).sum(dim=-1)
    return torch.clamp(ent(m)-.5*(ent(p)+ent(q)),min=0)

class Graph:
 def __init__(self,x,y,gamma,alpha):
    self.x=np.asarray(x,float);self.labels=np.asarray(y,int);self.n,self.d=self.x.shape;self.k=int(y.max())+1
    self.alpha=torch.as_tensor(alpha,dtype=DT)
    self.avail=torch.as_tensor(np.isfinite(x),dtype=torch.bool)
    B=shared_feature_kernel(x,gamma);self.B=torch.as_tensor(B,dtype=DT)
    self.yhot=torch.as_tensor(np.eye(self.k)[y],dtype=DT)
    self.qbase=torch.einsum('bij,jc->ibc',self.B,self.yhot)
 def subset(self,origins):
    idx=np.asarray(origins,int);m=len(idx); n=self.n;d=self.d
    present=np.isfinite(self.x)
    B=self.B.numpy()
    den=np.empty((m,n,d),float)
    qinter=np.empty((m,n,d,self.k),float)
    for m_idx,s in enumerate(idx):
      for b in range(d):
        Bex=B[b].copy();Bex[:,s]=0
        den[m_idx,:,b]=Bex.sum(1)
        qinter[m_idx,:,b,:]=Bex@self.yhot.numpy()
    valid=den>1e-12
    if not valid.any(axis=2).all() or not present[idx].any(axis=1).all(): raise ArithmeticError('deadend')
    qinter=np.divide(qinter,den[:,:,:,None],out=np.zeros_like(qinter),where=valid[:,:,:,None])
    return Subgraph(self,idx,den,valid,qinter)

class Subgraph:
 def __init__(self,g,idx,den,valid,qinter):
    self.g=g;self.idx=torch.tensor(idx,dtype=torch.long);self.m=len(idx)
    self.den=torch.as_tensor(den,dtype=DT)
    self.valid=torch.as_tensor(valid,dtype=torch.bool)
    self.qinter=torch.as_tensor(qinter,dtype=DT)
    self.state_mask=g.avail[None,:,:] & self.valid.any(dim=-1)[:,:,None]
    self.firstvalid=g.avail[self.idx]
    self.start=g.B[:,self.idx,:].permute(1,2,0).contiguous()
    self.qstart=g.qbase[self.idx]
 def softmax(self,z,mask):return torch.softmax(z.masked_fill(~mask,-1e20),dim=-1)
 def pol(self,z):
    g=self.g; m=self.m;n=g.n;d=g.d
    return self.softmax(z[:d][None,None,:,:].expand(m,n,-1,-1),self.valid[:,:,None,:].expand(m,n,d,d))
 def first(self,z):return self.softmax(z[self.g.d][None,:].expand(self.m,-1),self.firstvalid)
 def q_loss(self,z,target):
    pi=self.pol(z)
    dist=torch.einsum('miab,mibc->miac',pi,self.qinter)
    target=target.reshape(1,1,1,-1)
    valid=self.state_mask
    lossinter=(jsd(dist,target)*valid).sum()/valid.sum()
    pi0=self.first(z)
    firstdist=torch.einsum('mb,mbc->mc',pi0,self.qstart)
    return .5*(lossinter+jsd(firstdist,target.reshape(-1)[None,:]).mean())
 def center(self,z):
    g=self.g
    pi=self.pol(z)
    state=self.start*self.first(z)[:,None,:]
    center=torch.zeros(g.k,dtype=DT)
    for t,alpha in enumerate(g.alpha):
      center=center+alpha*torch.einsum('mjb,jc->c',state,g.yhot)/self.m
      if t+1==len(g.alpha):break
      choose=torch.einsum('mja,mjab->mjb',state,pi)
      steps=[]
      for b in range(g.d):
        w=torch.where(self.valid[:,:,b],choose[:,:,b]/self.den[:,:,b].clamp_min(1e-12),torch.zeros_like(choose[:,:,b]))
        nxt=w@g.B[b]
        nxt=nxt.scatter(1,self.idx[:,None],0.)
        steps.append(nxt)
      state=torch.stack(steps,dim=-1)
    return center

def fit(seed,n,cls,init,Qsteps=100,GNsteps=30):
    t0=time.perf_counter();dat=np.load(ROOT/'data'/f'train_{seed}.npz');Yall=dat['y'];ref=np.arange(300) if n==300 else subset150(seed,Yall)
    x=dat['x'][ref];y=Yall[ref];target=np.load(ROOT/'data'/f'bayes_target_{seed}.npy')[cls]
    target_t=torch.tensor(target,dtype=DT)
    graph=Graph(x,y,spec(seed)['gamma'],alpha_from_project(.4,.8,12))
    sg=graph.subset(np.flatnonzero(y==cls))
    if init=='zero':z0=np.zeros((graph.d+1,graph.d),float)
    elif init=='random':
       rng=np.random.default_rng(20261241+100*(seed-20261102)+10*(n==300)+cls)
       z0=rng.normal(0,.5,size=(graph.d+1,graph.d));z0-=z0.mean(-1,keepdims=True)
    else:raise ValueError('bad init')
    z=torch.nn.Parameter(torch.as_tensor(z0.copy(),dtype=DT));optim=torch.optim.Adam([z],lr=.12)
    Qlogs=[]
    for it in range(Qsteps):
       optim.zero_grad();loss=sg.q_loss(z,target_t)
       if not torch.isfinite(loss):raise ArithmeticError('nonfinite Q loss')
       loss.backward();optim.step()
       if (it+1)%10==0 or it==0:Qlogs.append([it+1,float(loss.item())])
    with torch.no_grad():
       qend=sg.center(z);qloss=float(jsd(qend,target_t).item());qz=z.detach().numpy().copy()
    damping=1e-3;trace=[];best=qloss;best_z=qz.copy();best_ctr=qend.numpy().copy()
    stalled=0
    for it in range(GNsteps):
       zloc=torch.tensor(best_z,dtype=DT,requires_grad=True)
       F=lambda t:sg.center(t)
       ctr=F(zloc)
       residual=ctr-target_t
       J=torch.autograd.functional.jacobian(F,zloc,create_graph=False).reshape(graph.k,-1).detach().numpy()
       rr=residual.detach().numpy()
       if not np.isfinite(J).all():raise ArithmeticError('GN nonfinite J')
       damping_try=damping;accepted=False
       for bt in range(12):
          step=np.linalg.solve(J.T@J + damping_try*np.eye(J.shape[1]), -J.T@rr).reshape(best_z.shape)
          zcand=best_z+step
          with torch.no_grad():c=sg.center(torch.as_tensor(zcand,dtype=DT));v=float(jsd(c,target_t).item())
          if np.isfinite(v) and v < best-1e-13:
            best=v;best_z=zcand.copy();best_ctr=c.numpy().copy();accepted=True;damping=max(damping_try/2,1e-9);break
          damping_try*=5
       trace.append({'GN_step':it+1,'best_JSD':best,'accepted':accepted,'damping':damping})
       if accepted:stalled=0
       else:stalled+=1
       if best<1e-12 or stalled>=3:break
    with torch.no_grad():
      ctr=sg.center(torch.as_tensor(best_z,dtype=DT)).detach().numpy()
    if np.max(np.abs(ctr-best_ctr))>1e-10:raise ArithmeticError('center replay mismatch')
    out={'status':'PASS_BOUNDED_BAYES_FIT','seed':seed,'n':n,'class':cls,'initialization':init,'init_seed':None if init=='zero' else 20261241+100*(seed-20261102)+10*(n==300)+cls,'source_train_sha256':json.loads((ROOT/'data/freeze_manifest.json').read_text())['seeds'][str(seed)]['canonical_train_sha256'],'target_sha256':sha(np.array(target,dtype='<f8').tobytes()),'target':target.tolist(),'Q_steps_completed':Qsteps,'Q_trace':Qlogs,'Q_end_exact_JSD':qloss,'GN_max_steps':GNsteps,'GN_steps_completed':len(trace),'GN_trace':trace,'best_exact_JSD':best,'center':ctr.tolist(),'z':best_z.tolist(),'wall_seconds':time.perf_counter()-t0,'peak_rss_mib_linux':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024,'H':12,'beta':.4,'lambda':.8,'method':'Q100+exact_center_GN_damped30','scientific_scope':'BOUNDED_SOLVER_SUCCESS_NOT_GLOBAL_OPTIMUM'}
    dest=ROOT/'results'/f'solver_s{seed}_n{n}_class{cls}_{init}.json'
    if dest.exists():raise FileExistsError(str(dest))
    dest.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'output':str(dest),'seed':seed,'n':n,'class':cls,'init':init,'Q_JSD':qloss,'best_JSD':best,'wall':round(out['wall_seconds'],2)}),flush=True)
    return out

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--seed',type=int,required=True);p.add_argument('--n',type=int,required=True);p.add_argument('--class',type=int,required=True,dest='cls');p.add_argument('--init',required=True,choices=('zero','random'));p.add_argument('--Q',default=100,type=int);p.add_argument('--GN',default=30,type=int)
    a=p.parse_args();fit(a.seed,a.n,a.cls,a.init,a.Q,a.GN)
