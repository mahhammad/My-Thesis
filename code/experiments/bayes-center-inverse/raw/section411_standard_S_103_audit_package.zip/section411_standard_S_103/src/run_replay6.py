"""Six exact end-to-end Train/Validation/Test replays, no model fitting."""
import subprocess,sys,os,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for i,(seed,n) in enumerate([(s,k) for s in (20261102,20261103,20261104) for k in (150,300)]):
  p=ROOT/'results'/f'replay_s{seed}_n{n}.json'
  if p.exists():
    a=json.loads(p.read_text());assert a['status']=='PASS_INDEPENDENT_NUMPY_FORWARD_REPLAY';print(f'[{i+1}/6] EXISTS {seed} n{n}',flush=True);continue
  r=subprocess.run([sys.executable,str(ROOT/'src/replay_metrics.py'),'--seed',str(seed),'--n',str(n)],env=os.environ,capture_output=True,text=True,timeout=600)
  if r.returncode:raise RuntimeError(f'REPLAY FAILED {seed} n{n}: '+r.stderr[-1000:])
  print(f'[{i+1}/6] '+r.stdout.strip(),flush=True)
