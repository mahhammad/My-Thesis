"""Non-training QA suite for R02 §4.11 standard S package."""
import hashlib,itertools,json,unittest,sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
from bounds_run import subset150
from replay_metrics import feature_kernel
from generate_frozen import spec

def load(p):return json.loads(Path(p).read_text())
class QA(unittest.TestCase):
 def test_exact_six_graph_h1_vs_independent_closed_form(self):
  for seed,n in itertools.product((20261102,20261103,20261104),(150,300)):
    d=np.load(ROOT/'data'/f'train_{seed}.npz');ids=np.arange(300) if n==300 else subset150(seed,d['y'])
    x=d['x'][ids];y=d['y'][ids];K=3
    B=feature_kernel(x,spec(seed)['gamma']);yhot=np.eye(K)[y]
    q=np.einsum('bij,jc->ibc',B,yhot)
    available=np.isfinite(x)
    lo=np.stack([np.where(available,q[:,:,c],np.inf).min(axis=1) for c in range(K)],axis=1)
    hi=np.stack([np.where(available,q[:,:,c],-np.inf).max(axis=1) for c in range(K)],axis=1)
    class_lo=np.stack([lo[y==c].mean(axis=0) for c in range(K)])
    class_hi=np.stack([hi[y==c].mean(axis=0) for c in range(K)])
    v=load(ROOT/'results'/f'bounds_s{seed}_n{n}_H1_b0p4_l0p8.json')
    np.testing.assert_allclose(class_lo,v['lower_center_probabilities'],rtol=0,atol=4e-13)
    np.testing.assert_allclose(class_hi,v['upper_center_probabilities'],rtol=0,atol=4e-13)
 def test_three_seeds_train_sha_and_nested_ids(self):
  m=load(ROOT/'data/freeze_manifest.json')
  assert m['seeds']['20261102']['canonical_train_sha256']=='2986b25a1dcb2421f9c2b15445a75b6ade5595469ad1362b6da6656ec1b30e93'
  expectations={20261102:'dbe477c65d28e526a31f18930f41d9213c66dd34d6f2966f7be8d78ab59475cd',20261103:'5876e835bb77e55439b8e1291163447815470d95e64d705ca323d001ce4161b6',20261104:'dd9916eab7e5eb202c318c331cf83e23b32603df10e70fdd46587d05adcae692'}
  for seed,expected in expectations.items():
   d=np.load(ROOT/'data'/f'train_{seed}.npz');ids=subset150(seed,d['y'])
   sha=hashlib.sha256(np.ascontiguousarray(ids,dtype='<i8').tobytes()).hexdigest()
   assert sha==expected
   assert np.bincount(d['y'][ids],minlength=3).tolist()==[50,50,50]
 def test_all_solver_centers_replayed_independently(self):
  for seed,n in itertools.product((20261102,20261103,20261104),(150,300)):
   a=load(ROOT/'results'/f'replay_s{seed}_n{n}.json')
   for k,v in a['results'].items():
    ctr=np.asarray(v['centers']);assert np.abs(ctr.sum(axis=1)-1).max()<1e-9
    for split,s in v['metrics'].items():
     q=np.asarray(s['hypothesis_representations']);self.assertTrue(np.isfinite(q).all());np.testing.assert_allclose(q.sum(-1),1,rtol=0,atol=1e-8)
     assert abs(s['balanced_accuracy']-np.mean(np.diag(s['confusion_true_rows_pred_cols'])/np.sum(s['confusion_true_rows_pred_cols'],axis=1)))<1e-12
     assert len(s['predictions'])==s['N']
    if k=='Bayes_target_Q100_GN30':
     for c,row in enumerate(v['policy_selection']):
      from replay_metrics import jsd
      target=np.load(ROOT/'data'/f'bayes_target_{seed}.npy')[c]
      self.assertLessEqual(abs(float(jsd(ctr[c],target))-row['selected_exact_train_JSD']),1e-10)
 def test_six_rigorous_assumption_disclosures(self):
  for seed,n in itertools.product((20261102,20261103,20261104),(150,300)):
   r=load(ROOT/'checks'/f'precision_s{seed}_n{n}_H12.json')
   assert r['QA']=='NEEDS_INDEPENDENT_REVIEW'
   assert r['max_lower_deviation_from_candidate']>0
   assert r['max_upper_deviation_from_candidate']>0
   lo=np.array(r['lower_center_enclosure']);hi=np.array(r['upper_center_enclosure'])
   base=load(ROOT/'results'/f'bounds_s{seed}_n{n}_H12_b0p4_l0p8.json')
   assert (lo<=np.array(base['lower_center_probabilities'])).all()
   assert (hi>=np.array(base['upper_center_probabilities'])).all()
 def test_uniform_original_seed02_baseline(self):
  d=load(ROOT/'results/replay_s20261102_n300.json')['results']['uniform']['metrics']
  for split,v in [('train',.83646),('validation',.96769),('test',.76418)]:
    self.assertAlmostEqual(d[split]['balanced_accuracy'],v,delta=3e-5)
if __name__=='__main__':unittest.main(verbosity=2)
