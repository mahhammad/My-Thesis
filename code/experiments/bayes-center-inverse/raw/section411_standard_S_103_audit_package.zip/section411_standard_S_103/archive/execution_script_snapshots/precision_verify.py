"""Independent conservative arithmetic enclosure for true origin-excluded Bellman bounds.

The input x/gamma and beta/lambda are exactly their serialized binary64 values.
Gaussian weights are evaluated via correctly rounded decimal exp at 70 digits,
and all later positive arithmetic is enclosed with deliberately oversized 1e-10
per operation relative error (covers n<=300 positive-sum BLAS roundoff).
No access to candidate Bellman source, only saved candidate 3x3 output.
This is a *conservative enclosure under the stated IEEE/Decimal assumptions*;
scientific audit of these assumptions and independent implementation is still needed.
"""
from __future__ import annotations
import os,sys,time,json,hashlib,argparse,resource,decimal
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
from bounds_run import subset150,alpha_from_project
from generate_frozen import spec,sha
EPS=1e-10  # per-operation enlargement much bigger than gamma_{2*300}
DPS=70

def go_up(a):return np.nextafter(np.asarray(a,dtype=np.float64),np.inf)
def go_down(a):return np.nextafter(np.asarray(a,dtype=np.float64),-np.inf)

def b_decimal_interval(x,gamma):
    n,d=x.shape;mask=np.isfinite(x)
    lo=np.zeros((d,n,n),dtype=np.float64);hi=np.zeros_like(lo)
    decimal.getcontext().prec=DPS
    saved=[decimal.Decimal(float(g)) for g in gamma]
    z=[[decimal.Decimal(float(x[i,b])) if mask[i,b] else None for i in range(n)] for b in range(d)]
    for b in range(d):
      for i in range(n):
        if not mask[i,b]:continue
        ws=[];total=decimal.Decimal(0)
        for j in range(n):
          if j==i or not mask[j,b]:ws.append(decimal.Decimal(0));continue
          diff=z[b][i]-z[b][j]
          w=(-saved[b]*diff*diff).exp()
          ws.append(w);total+=w
        if total<=0:raise ArithmeticError('decimal kernel total zero')
        for j,w in enumerate(ws):
          if not w:continue
          p=float(w/total)
          # 4-ULP padding covers Decimal's correct rounding at prec70 and conversion.
          v=p
          for _ in range(4):v=float(np.nextafter(v,-np.inf))
          lo[b,i,j]=max(0.,v)
          v=p
          for _ in range(4):v=float(np.nextafter(v,np.inf))
          hi[b,i,j]=v
    if not np.all(np.isfinite(lo)) or not np.all(np.isfinite(hi)) or np.any(lo>hi):raise ArithmeticError('kernel interval invalid')
    if (np.abs(np.minimum(lo.sum(2).T-1,0))[mask]>1e-6).any():raise ArithmeticError('kernel interval lower not sufficiently normalized')
    if np.any((hi.sum(2).T+1e-6<1)[mask]):raise ArithmeticError('kernel interval upper not normalized')
    return lo,hi

def alpha_interval(beta,lam,H):
    decimal.getcontext().prec=DPS
    bd=decimal.Decimal(float(beta));ld=decimal.Decimal(float(lam));one=decimal.Decimal(1)
    a=[decimal.Decimal(0) for _ in range(H)]
    for ell in range(1,H+1):
      prob=bd*(one-bd)**(ell-1) if ell<H else (one-bd)**(H-1)
      denom=sum((ld**(t-1) for t in range(1,ell+1)),decimal.Decimal(0))
      for t in range(1,ell+1):a[t-1]+=prob*ld**(t-1)/denom
    arr=np.array([float(v) for v in a]);
    a_lo=arr.copy();a_hi=arr.copy()
    for _ in range(4):a_lo=go_down(a_lo);a_hi=go_up(a_hi)
    if not (np.sum(a_lo)<1 and np.sum(a_hi)>1):raise AssertionError('alpha not enclosing 1')
    return a_lo,a_hi

def safe_positive_sum(arr,axis):
    v=arr.sum(axis=axis)
    return go_down(np.maximum(0.,v*(1-EPS))),go_up(v*(1+EPS))

def interval_bounds(x,labels,gamma,beta,lam,H):
    t0=time.perf_counter();n,d=x.shape;K=len(np.unique(labels))
    B_lo,B_hi=b_decimal_interval(x,gamma)
    a_lo,a_hi=alpha_interval(beta,lam,H)
    bsecs=time.perf_counter()-t0
    perlo=np.empty((n,K));perhi=np.empty((n,K));denmin=float('inf')
    for origin in range(n):
      loex=np.concatenate([B_lo[:,:,:origin],B_lo[:,:,origin+1:]],axis=2)
      hiex=np.concatenate([B_hi[:,:,:origin],B_hi[:,:,origin+1:]],axis=2)
      DL0=loex.sum(axis=2).T
      DH0=hiex.sum(axis=2).T
      denlo=go_down(np.maximum(0,DL0*(1-EPS)))
      denhi=go_up(DH0*(1+EPS))
      possible=denhi>1e-12
      certain=denlo>1e-12
      if not np.array_equal(certain,possible):raise ArithmeticError(f'legal mask uncertain at origin {origin}')
      if H>1 and not certain.any(axis=1).all():raise ArithmeticError('deadend')
      denmin=min(denmin,float(denlo[certain].min()))
      starts=np.isfinite(x[origin])
      if not starts.any():raise ArithmeticError('bad start')
      for c in range(K):
        reward=(labels==c).astype(float)
        low=np.broadcast_to((a_lo[-1]*reward)[:,None],(n,d)).copy()
        high=np.broadcast_to((a_hi[-1]*reward)[:,None],(n,d)).copy()
        for t in range(H-2,-1,-1):
          low[origin,:]=0;high[origin,:]=0
          nl=np.einsum('bij,jb->ib',B_lo,low,optimize=True)
          nh=np.einsum('bij,jb->ib',B_hi,high,optimize=True)
          nl=go_down(np.maximum(0,nl*(1-EPS)));nh=go_up(nh*(1+EPS))
          qlo=go_down(np.divide(nl,denhi,out=np.zeros_like(nl),where=certain)*(1-EPS))
          qhi=go_up(np.divide(nh,denlo,out=np.zeros_like(nh),where=certain)*(1+EPS))
          bestlo=np.where(certain,qlo,np.inf).min(axis=1)
          besthi=np.where(certain,qhi,-np.inf).max(axis=1)
          bestlo[origin]=0;besthi[origin]=0
          low=np.broadcast_to(go_down(np.maximum(0,(a_lo[t]*reward+bestlo)*(1-EPS)))[:,None],(n,d)).copy()
          high=np.broadcast_to(go_up((a_hi[t]*reward+besthi)*(1+EPS))[:,None],(n,d)).copy()
        startlo=np.einsum('bj,jb->b',B_lo[:,origin,:],low,optimize=True)
        starthi=np.einsum('bj,jb->b',B_hi[:,origin,:],high,optimize=True)
        perlo[origin,c]=float(go_down(np.min(np.maximum(0,startlo[starts]*(1-EPS)))))
        perhi[origin,c]=float(go_up(np.max(starthi[starts]*(1+EPS))))
    lo=[];hi=[]
    for cls in range(K):
      l=perlo[labels==cls].mean(axis=0)
      u=perhi[labels==cls].mean(axis=0)
      lo.append(go_down(np.maximum(0,l*(1-EPS))))
      hi.append(go_up(u*(1+EPS)))
    return np.array(lo),np.array(hi),{'decimal_kernel_seconds':bsecs,'bellman_seconds':time.perf_counter()-t0-bsecs,'minimum_legal_denominator_lower_bound':denmin,'per_op_relative_slack':EPS,'decimal_digits':DPS}

def run(seed,n):
    t0=time.perf_counter();seed=int(seed);n=int(n)
    source=ROOT/'results'/f'bounds_s{seed}_n{n}_H12_b0p4_l0p8.json'
    assert source.is_file(),source
    z=json.loads(source.read_text()); assert z['source_git_blob']=='7fe3ae82f10b3120054854f82ee3916c55605f30'
    data=np.load(ROOT/'data'/f'train_{seed}.npz');ya=data['y'];ids=np.arange(300) if n==300 else subset150(seed,ya)
    x=data['x'][ids];y=ya[ids];gamma=spec(seed)['gamma']
    lower,upper,diag=interval_bounds(x,y,gamma,.4,.8,12)
    candidate_lo=np.array(z['lower_center_probabilities']);candidate_hi=np.array(z['upper_center_probabilities'])
    lower_error=float((candidate_lo-lower).max());upper_error=float((upper-candidate_hi).max())
    if (lower>candidate_lo+1e-7).any() or (upper<candidate_hi-1e-7).any():raise AssertionError('candidate not enclosed by validation method')
    decisions={}
    for name,v in z['targets'].items():
      t=np.array(v['target']);badlo=lower-t;badhi=t-upper
      delta=np.maximum(badlo,badhi);maxgap=float(delta.max())
      decisions[name]={'status':'CERTIFIABLE_CONDITIONAL_ON_METHOD_QA' if maxgap>0 else 'NOT_EXCLUDED_COORDINATEWISE','max_validated_coordinate_gap':maxgap,'lower_exclusion_gaps':badlo.tolist(),'upper_exclusion_gaps':badhi.tolist(),'argmax_rowcol':[int(v) for v in np.unravel_index(int(np.argmax(delta)),delta.shape)]}
    result={'status':'PASS_CONSERVATIVE_ENCLOSURE_UNDER_STATED_ARITHMETIC_ASSUMPTIONS','QA':'NEEDS_INDEPENDENT_REVIEW','seed':seed,'n':n,'beta':.4,'lambda':.8,'H':12,'input_bounds_path':str(source.relative_to(ROOT)),'lower_center_enclosure':lower.tolist(),'upper_center_enclosure':upper.tolist(),'max_lower_deviation_from_candidate':lower_error,'max_upper_deviation_from_candidate':upper_error,'precision_diagnostics':diag,'target_decisions':decisions,'total_wall_seconds':time.perf_counter()-t0,'peak_rss_mib_linux':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024}
    dest=ROOT/'checks'/f'precision_s{seed}_n{n}_H12.json'
    if dest.exists():raise FileExistsError(str(dest))
    dest.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'seed':seed,'n':n,'wall':round(result['total_wall_seconds'],2),'precision_max_error':max(lower_error,upper_error),'decisions':{a:b['max_validated_coordinate_gap'] for a,b in decisions.items()}}),flush=True)
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--seed',required=True,type=int);p.add_argument('--n',required=True,type=int);a=p.parse_args();run(a.seed,a.n)
