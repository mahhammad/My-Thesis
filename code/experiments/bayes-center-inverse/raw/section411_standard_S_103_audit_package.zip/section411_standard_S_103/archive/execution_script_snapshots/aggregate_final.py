"""R02 §4.11 complete reproducible S=103 audit summary.
Hard-fail if any of 54+6+36+6+1 required units or hash checks missing.
No historical invalid bound imported. Only new V2+independent check+replay.
"""
from __future__ import annotations
import hashlib,math,json,glob,os,itertools,platform,zipfile,statistics
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
P=[(1,.4,.8),(2,.4,.8),(3,.4,.8),(4,.4,.8),(12,.4,.8),(12,.2,.8),(12,.7,.8),(12,.4,.4),(12,.4,1.)]
seeds=(20261102,20261103,20261104); sizes=(150,300)
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def jsbinary(p,q):
  def ent(x):return -(x*math.log(x) if x>0 else 0)-((1-x)*math.log(1-x) if x<1 else 0)
  return ent(.5*(p+q))-.5*(ent(p)+ent(q))
def coarsening_lower(C,target):
  L=np.asarray(C['lower_center_enclosure']);U=np.asarray(C['upper_center_enclosure']);T=np.asarray(target)
  K=len(L); val=[];arg=[]
  for c in range(K):
    best=0.;bestidx=None
    for k in range(K):
      x=T[c,k];
      if x<L[c,k]:bound=jsbinary(L[c,k],x)
      elif x>U[c,k]:bound=jsbinary(U[c,k],x)
      else:bound=0.
      if bound>best:best=bound;bestidx=[c,k]
    val.append(float(best));arg.append(bestidx)
  return {'balanced_mean_JSD_lower_bound':float(np.mean(val)),'per_class_JSD_lower_bound':val,'argmax_component':arg,'derivation':'JSD data processing under per-coordinate binary coarsening, using conservative interval endpoints; pending independent QA'}

def main():
  manifest=load(ROOT/'data/freeze_manifest.json'); rows=[]; prec=[]; solves=[]; replays=[]
  for seed,n in itertools.product(seeds,sizes):
    for H,b,l in P:
      path=ROOT/'results'/f'bounds_s{seed}_n{n}_H{H}_b{str(b).replace(".","p")}_l{str(l).replace(".","p")}.json'
      assert path.exists(),f'Missing bound {path}'
      r=load(path)
      assert r['status']=='PASS_FLOAT64_NUMERICAL_ONLY' and not r['diagnostic_only']
      assert r['source_git_blob']=='7fe3ae82f10b3120054854f82ee3916c55605f30'
      assert (r['seed'],r['n'],r['H'],r['beta'],r['lambda'])==(seed,n,H,b,l)
      assert r['input']['canonical_train_sha256']==manifest['seeds'][str(seed)]['canonical_train_sha256']
      lo=np.array(r['lower_center_probabilities']);hi=np.array(r['upper_center_probabilities'])
      assert np.all(np.isfinite(lo)) and np.all(np.isfinite(hi)) and np.all(lo<=hi+1e-10)
      rows.append({'seed':seed,'n':n,'H':H,'beta':b,'lambda':l,'SHA256':h(path),'wall_seconds':r['bound_wall_seconds'],'peak_rss_mib':r['peak_rss_mib_linux'],'diagonal_upper':np.diag(hi).tolist(),'bayes_max_raw_gap':r['targets']['bayes']['max_raw_violation']})
    checkfile=ROOT/'checks'/f'precision_s{seed}_n{n}_H12.json'
    p=load(checkfile)
    assert p['status']=='PASS_CONSERVATIVE_ENCLOSURE_UNDER_STATED_ARITHMETIC_ASSUMPTIONS' and p['QA']=='NEEDS_INDEPENDENT_REVIEW'
    p['proof_statements']={name:coarsening_lower(p,load(ROOT/'results'/f'bounds_s{seed}_n{n}_H12_b0p4_l0p8.json')['targets'][name]['target']) for name in p['target_decisions']}
    prec.append({'seed':seed,'n':n,'SHA256':h(checkfile),'max_bound_discrepancy':max(p['max_lower_deviation_from_candidate'],p['max_upper_deviation_from_candidate']),'target_decisions':p['target_decisions'],'JSD_lower_from_conservative_enclosure':p['proof_statements'],'wall_seconds':p['total_wall_seconds']})
    for c,init in itertools.product(range(3),('zero','random')):
      path=ROOT/'results'/f'solver_s{seed}_n{n}_class{c}_{init}.json'
      r=load(path)
      assert r['status']=='PASS_BOUNDED_BAYES_FIT' and r['Q_steps_completed']==100 and r['GN_max_steps']==30
      assert (r['seed'],r['n'],r['class'],r['initialization'])==(seed,n,c,init)
      assert r['source_train_sha256']==manifest['seeds'][str(seed)]['canonical_train_sha256']
      assert np.isfinite(r['best_exact_JSD']) and r['best_exact_JSD']>=0
      solves.append({'seed':seed,'n':n,'class':c,'initialization':init,'SHA256':h(path),'Q_steps':r['Q_steps_completed'],'GN_steps':r['GN_steps_completed'],'best_exact_JSD':r['best_exact_JSD'],'wall_seconds':r['wall_seconds'],'peak_rss_mib':r['peak_rss_mib_linux']})
    replayfile=ROOT/'results'/f'replay_s{seed}_n{n}.json'
    rr=load(replayfile)
    assert rr['status']=='PASS_INDEPENDENT_NUMPY_FORWARD_REPLAY' and (rr['seed'],rr['n'])==(seed,n)
    opt=rr['results']['Bayes_target_Q100_GN30']
    v=opt['metrics']['train']
    assert abs(v['R_KL_entropy_identity']-v['R_KL'])<1e-8
    assert len(v['hypothesis_representations'])==n and len(opt['centers'])==3
    replays.append({'seed':seed,'n':n,'SHA256':h(replayfile),'optimized':{split:{k:opt['metrics'][split][k] for k in ('balanced_accuracy','ordinary_accuracy','R_KL','R_JS','R_sqrt_JS')} for split in ('train','validation','test')},'uniform':{split:{k:rr['results']['uniform']['metrics'][split][k] for k in ('balanced_accuracy','ordinary_accuracy','R_KL','R_JS','R_sqrt_JS')} for split in ('train','validation','test')},'centers':opt['centers'],'center_geometry':opt['center_geometry'],'selected':opt['policy_selection'],'wall_seconds':rr['wall_seconds']})
  assert (len(rows),len(prec),len(solves),len(replays))==(54,6,36,6)
  probe=load(ROOT/'archive/probe_n150_H2_s20261102.json')
  assert probe['diagnostic_only'] and probe['n']==150 and probe['H']==2
  bysize={}
  for n in sizes:
    fits=[x for x in replays if x['n']==n]
    bysize[str(n)]={}
    for pol in ('optimized','uniform'):
      bysize[str(n)][pol]={}
      for split in ('train','validation','test'):
        v=np.array([q[pol][split]['balanced_accuracy'] for q in fits])
        bysize[str(n)][pol][split]={'mean':float(v.mean()),'sample_sd':float(v.std(ddof=1)),'individual_seeds':v.tolist()}
  pair={}
  for pol in ('optimized','uniform'):
    pair[pol]={}
    for split in ('train','validation','test'):
      vals=np.array([next(q for q in replays if q['seed']==s and q['n']==300)[pol][split]['balanced_accuracy']-next(q for q in replays if q['seed']==s and q['n']==150)[pol][split]['balanced_accuracy'] for s in seeds])
      pair[pol][split]={'mean_delta_300_minus_150':float(vals.mean()),'sample_sd':float(vals.std(ddof=1)),'per_seed_delta':vals.tolist()}
  d11=[p for p in prec if (p['seed'],p['n'])==(20261102,300)][0]
  payload={'schema':'SEC411_STANDARD_S_103_JOBS_V1','status':'COMPLETED_INTERNAL_QA_PENDING_INDEPENDENT_SCIENTIFIC_QA','no_invalid_historical_bounds_reused':True,'scientific_bounds':'EXCLUSION_CONDITIONAL_ON_INDEPENDENT_REVIEW_OF_INTERVAL_VERIFIER','data_freeze_manifest_SHA256':h(ROOT/'data/freeze_manifest.json'),'counts':{'original_invalid_bound_jobs_included':0,'bound_jobs':54,'independent_precision_jobs':6,'bayes_class_solver_jobs':36,'independent_metric_replay_jobs':6,'separate_resource_probe_jobs':1,'total_jobs':103,'independent_generator_seeds':3,'graph_sizes':[150,300],'per_graph_settings':9},'parameter_grid':P,'bound_runs':rows,'precision_checks':prec,'solver_runs':solves,'replay_runs':replays,'balanced_accuracy_summary':bysize,'paired_size_deltas':pair,'d11_new_fixed_target_assessment':{'source_seed':20261102,'source_graph_n':300,'H':12,'results':{k:d11['JSD_lower_from_conservative_enclosure'][k] for k in ('equal','bounded_equal')},'target_compatibility':{k:d11['target_decisions'][k] for k in ('equal','bounded_equal')}},'scientific_limitations':['No claim of global solver optimality','Independent scientific review of conservative arithmetic error envelope pending','Nonbaseline 48 settings are numerical sensitivity observations, not 48 certified infeasibility statements','Three generator seeds: paired n150 and n300 are not independent datasets','All Train selection only; Validation and Test evaluated after policies frozen','Old invalid bounds excluded from summary; retained only in separate archived repo ancestry'],'software':{'python':platform.python_version(),'numpy':np.__version__}}
  p=ROOT/'results/SEC411_STANDARD_S_103_SUMMARY.json';p.write_text(json.dumps(payload,indent=2,ensure_ascii=False,sort_keys=True,allow_nan=False)+'\n')
  print('COMPLETE 103',len(rows),len(prec),len(solves),len(replays),'probe',1)
  print('D11',json.dumps(payload['d11_new_fixed_target_assessment'],indent=2))
  print('BA',json.dumps(bysize,indent=2))
  return payload
if __name__=='__main__':main()
