"""§4.11 bounds V2 exact-origin-excluded: frozen source + independent metadata.
All outputs append-only; fail-closed on drift and invalid origin normalization.
"""
from __future__ import annotations
import argparse,hashlib,json,os,platform,resource,sys,time
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
SOURCE=Path('/mnt/data/section411_preflight_work/code/experiments/bayes_center_audit_pack/bound_repair_candidate')
sys.path.insert(0,str(SOURCE))
from exact_origin_excluded_bound import exact_origin_excluded_center_bounds,BOUND_KERNEL_VERSION,shared_feature_kernel
from generate_frozen import spec,sha

SRC_HASH='7fe3ae82f10b3120054854f82ee3916c55605f30'
REF_SEEDS={20261102:20261201,20261103:20261202,20261104:20261203}

def alpha_from_project(beta,lam,horizon):
    a=np.zeros(horizon,dtype=float)
    for ell in range(1,horizon+1):
        prob=beta*(1-beta)**(ell-1) if ell<horizon else (1-beta)**(horizon-1)
        den=sum(lam**(t-1) for t in range(1,ell+1))
        for t in range(1,ell+1): a[t-1]+=prob*lam**(t-1)/den
    assert np.isclose(a.sum(),1.,atol=1e-12)
    return a

def subset150(seed,y):
    rng=np.random.default_rng(REF_SEEDS[seed]); idx=np.concatenate([rng.choice(np.flatnonzero(y==c),50,replace=False) for c in range(3)]);rng.shuffle(idx)
    assert len(np.unique(idx))==150 and np.array_equal(np.bincount(y[idx],minlength=3),[50]*3)
    return idx

def filehash(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def job(seed,n,H,beta,lam,diagnostic=False):
    t0=time.perf_counter()
    seed=int(seed);n=int(n);H=int(H)
    if seed not in REF_SEEDS or n not in (150,300) or H not in (1,2,3,4,12):raise ValueError('unregistered config')
    data=np.load(ROOT/'data'/f'train_{seed}.npz');xall=data['x']; yall=data['y'];maskall=data['mask']
    frozen=json.loads((ROOT/'data/freeze_manifest.json').read_text())['seeds'][str(seed)]
    ids=np.arange(300) if n==300 else subset150(seed,yall)
    x=xall[ids];y=yall[ids]
    assert np.array_equal(np.isfinite(x),maskall[ids])
    assert sha(np.ascontiguousarray(yall,dtype='<i8').tobytes())==frozen['array_sha256']['y']
    xcanonical=np.ascontiguousarray(xall,dtype='<f8');xcanonical[~maskall]=np.float64(np.nan)
    assert sha(xcanonical.tobytes())==frozen['array_sha256']['X']
    target=np.load(ROOT/'data'/f'bayes_target_{seed}.npy')
    assert sha(np.ascontiguousarray(target,dtype='<f8').tobytes())==frozen['target_sha256']
    source_digest=hashlib.sha1(b'blob '+str(SOURCE.joinpath('exact_origin_excluded_bound.py').stat().st_size).encode()+b'\x00'+SOURCE.joinpath('exact_origin_excluded_bound.py').read_bytes()).hexdigest()
    assert source_digest==SRC_HASH
    coeff=alpha_from_project(beta,lam,H)
    kernel=shared_feature_kernel(x,spec(seed)['gamma'])
    assert kernel.shape==(5,n,n)
    assert np.isfinite(kernel).all() and np.all(kernel>=0)
    eligible=np.isfinite(x)
    assert (np.abs(kernel.sum(axis=2).T[eligible]-1)<1e-10).all()
    t1=time.perf_counter()
    b=exact_origin_excluded_center_bounds(x,y,spec(seed)['gamma'],coeff,return_per_origin=True)
    elapsed=time.perf_counter()-t1
    lower=np.array(b['lower_center_probabilities']);upper=np.array(b['upper_center_probabilities'])
    assert lower.shape==upper.shape==(3,3)
    assert np.isfinite(lower).all() and np.isfinite(upper).all()
    assert (lower>=-1e-10).all() and (upper<=1+1e-10).all() and (upper>=lower-1e-10).all()
    dtarget={"bayes":{"target":target.tolist(),"lower_gap":(lower-target).tolist(),"upper_gap":(target-upper).tolist(),"max_raw_violation":float(np.maximum.reduce([lower-target,target-upper,np.zeros_like(target)]).max())}}
    if (seed,n,H,beta,lam)==(20261102,300,12,.4,.8):
      frozen11={"equal":[[.6023781703724579,.19881091481377106,.19881091481377106],[.14011420403901742,.7197715919219652,.14011420403901742],[.1577272489810062,.1577272489810062,.6845455020379876]],"bounded_equal":[[.6023781703724579,.2963777752351273,.1012440543924148],[.14011420403901742,.7197715919219652,.14011420403901742],[.061362713494273635,.2540917844677388,.6845455020379876]]}
      for name,t in frozen11.items():
        z=np.array(t)
        dtarget[name]={"target":t,"lower_gap":(lower-z).tolist(),"upper_gap":(z-upper).tolist(),"max_raw_violation":float(np.maximum.reduce([lower-z,z-upper,np.zeros_like(z)]).max())}
    peak=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024 # Linux MiB
    out={'status':'PASS_FLOAT64_NUMERICAL_ONLY','seed':seed,'n':n,'H':H,'beta':beta,'lambda':lam,'alpha':coeff.tolist(),'kernel':BOUND_KERNEL_VERSION,'d':5,'K':3,'ids_sha256':sha(np.ascontiguousarray(ids,dtype='<i8').tobytes()),'input':frozen,'source_git_blob':SRC_HASH,'generator_source_blob':'bd9fd2c57a7c37201e44978c599a5a07999a35bb','config_blob':'047d3758417618740b1217eb573db60dcb92607b','lower_center_probabilities':lower.tolist(),'upper_center_probabilities':upper.tolist(),'per_origin_bounds_SHA256':sha(np.ascontiguousarray(np.array(b['lower_per_origin']+b['upper_per_origin']),dtype='<f8').tobytes()),'targets':dtarget,'bound_wall_seconds':elapsed,'total_wall_seconds':time.perf_counter()-t0,'peak_rss_mib_linux':peak,'runtime':{'python':platform.python_version(),'numpy':np.__version__},'diagnostic_only':diagnostic,'certificate':'NOT_VALIDATED_RIGOROUS_INTERVAL'}
    dest=ROOT/'results'/f'bounds_s{seed}_n{n}_H{H}_b{str(beta).replace(".","p")}_l{str(lam).replace(".","p")}.json'
    if dest.exists():raise FileExistsError('immutable output already exists '+str(dest))
    dest.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'output':str(dest),'status':out['status'],'seed':seed,'n':n,'H':H,'beta':beta,'lambda':lam,'wall':round(elapsed,3),'RSS_MiB':round(peak,1),'max_target_violation':dtarget['bayes']['max_raw_violation']},sort_keys=True),flush=True)
    return out

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--seed',type=int,required=True);p.add_argument('--n',type=int,required=True);p.add_argument('--H',type=int,required=True)
    p.add_argument('--beta',type=float,default=.4);p.add_argument('--lam',type=float,default=.8);p.add_argument('--diagnostic',action='store_true')
    args=p.parse_args();job(args.seed,args.n,args.H,args.beta,args.lam,args.diagnostic)
