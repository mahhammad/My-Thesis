"""D10/D11 canonical data recreation, faithful to Git blob bd9fd... generate.py."""
import json,hashlib,tempfile
from pathlib import Path
import numpy as np

CONFIG = {
  'seed':20261102, 'split_sizes':{'train':300,'validation':90,'test':120},
  'class_priors':[.25,.45,.30],
  'means':[[-2.,-.3,0.,-1.2,0.],[0.,.7,0.,0.,0.],[2.,-.4,0.,1.2,0.]],
  'stds':[[.95,1.,1.2,.95,1.1]]*3,
  'correlation':[[1.,.35,0.,.2,0.],[.35,1.,0.,0.,0.],[0.,0.,1.,0.,.3],[.2,0.,0.,1.,0.],[0.,0.,.3,0.,1.]],
  'missing_percent':[0,5,12,5,20], 'kernel_gamma':[.8,1.2,.5,1.,.6]
}

def spec(seed):
    cfg={**CONFIG,'seed':int(seed)}
    pi=np.array(cfg['class_priors'],float);mu=np.array(cfg['means'],float);sd=np.array(cfg['stds'],float);corr=np.array(cfg['correlation'],float)
    cov=sd[:,:,None]*corr[None,:,:]*sd[:,None,:]
    return {'seed':int(seed),'pi':pi,'mu':mu,'sd':sd,'corr':corr,'cov':cov,'missing':np.array(cfg['missing_percent'],float)/100.,'gamma':np.array(cfg['kernel_gamma'],float)}

def softmax(logits,axis=-1):
    z=logits-np.max(logits,axis=axis,keepdims=True)
    w=np.exp(z)
    return w/w.sum(axis=axis,keepdims=True)

def posterior(s,x):
    x=np.asarray(x,float);n,k=len(x),len(s['pi'])
    logp=np.broadcast_to(np.log(s['pi']),(n,k)).copy()
    observed=np.isfinite(x)
    for pattern in np.unique(observed,axis=0):
        rows=np.flatnonzero(np.all(observed==pattern,axis=1))
        idx=np.flatnonzero(pattern)
        if not len(idx): continue
        for c in range(k):
            cov=s['cov'][c][np.ix_(idx,idx)]
            chol=np.linalg.cholesky(cov)
            residual=(x[np.ix_(rows,idx)]-s['mu'][c,idx]).T
            whitened=np.linalg.solve(chol,residual)
            logp[rows,c]-=(0.5*np.sum(whitened**2,axis=0)
                +np.log(np.diag(chol)).sum()+0.5*len(idx)*np.log(2*np.pi))
    return softmax(logp)

def recreate(seed):
    s=spec(seed)
    children=np.random.SeedSequence(s['seed']).spawn(3)
    outputs={}
    for name,child,n in zip(('train','validation','test'),children,(300,90,120)):
        rng=np.random.default_rng(child)
        y=rng.choice(len(s['pi']),size=n,p=s['pi'])
        x=np.empty((n,s['mu'].shape[1]))
        for c in range(len(s['pi'])):
            idx=np.flatnonzero(y==c)
            if len(idx):x[idx]=rng.multivariate_normal(s['mu'][c],s['cov'][c],size=len(idx))
        mask=rng.random(x.shape)>=s['missing'][None,:]
        x[~mask]=np.nan
        outputs[name]=(x,mask,y)
    return outputs

def canon(x,y,mask,ids):
    MAGIC=b'B02TRAIN_CANONICAL_V1\n'
    z=np.array(x,dtype='<f8',order='C',copy=True);z[~mask]=np.float64(np.nan)
    ys=np.ascontiguousarray(y,dtype='<i8');ms=np.ascontiguousarray(mask.astype('u1'));ix=np.ascontiguousarray(ids,dtype='<i8')
    return MAGIC+z.tobytes(order='C')+ys.tobytes(order='C')+ms.tobytes(order='C')+ix.tobytes(order='C')

def sha(b):return hashlib.sha256(b).hexdigest()

if __name__=='__main__':
    out=Path('/mnt/data/section411_full_standard_20261114/data');out.mkdir(parents=True,exist_ok=True)
    legacy=np.array([[.7786352661736342,.21928110527447797,.002083628551887826],[.1624270985661503,.7318229635896072,.1057499378442424],[.0016181879372700126,.12564189466674763,.8727399173959823]])
    frozen={'source_git_blob':'bd9fd2c57a7c37201e44978c599a5a07999a35bb','config_git_blob':'047d3758417618740b1217eb573db60dcb92607b','seeds':{}}
    for seed in (20261102,20261103,20261104):
        outputs=recreate(seed);x,mask,y=outputs['train']
        p=posterior(spec(seed),x)
        target=np.vstack([p[y==c].mean(axis=0) for c in range(3)])
        xcan=np.array(x,dtype='<f8',copy=True);xcan[~mask]=np.float64(np.nan)
        h={'X':sha(xcan.tobytes()),'y':sha(np.ascontiguousarray(y,dtype='<i8').tobytes()),'mask':sha(mask.astype('u1').tobytes()),'ids':sha(np.arange(300,dtype='<i8').tobytes())}
        binary=canon(x,y,mask,np.arange(300))
        targethash=sha(np.ascontiguousarray(target,dtype='<f8').tobytes())
        exact_legacy=bool(np.array_equal(target,legacy))
        max_diff=float(np.max(np.abs(target-legacy)))
        frozen['seeds'][str(seed)]={'class_counts':np.bincount(y,minlength=3).tolist(),'array_sha256':h,'canonical_train_sha256':sha(binary),'target_sha256':targethash,'target':target.tolist(),'target_max_difference_vs_legacy_seed02':max_diff if seed==20261102 else None,'target_exact_legacy':exact_legacy if seed==20261102 else None}
        for name,(u,ms,z) in outputs.items():np.savez_compressed(out/f'{name}_{seed}.npz',x=u,mask=ms,y=z)
        np.save(out/f'bayes_posterior_train_{seed}.npy',p)
        np.save(out/f'bayes_target_{seed}.npy',target)
        print(seed, frozen['seeds'][str(seed)],flush=True)
    (out/'freeze_manifest.json').write_text(json.dumps(frozen,indent=2,sort_keys=True)+'\n')
    assert frozen['seeds']['20261102']['class_counts']==[72,147,81]
    assert frozen['seeds']['20261102']['array_sha256']['X']=='51699bbe51504fa82d3e27aaa9ea81428bf341c4a0f2e5de67dcb3badd9a6852'
    assert frozen['seeds']['20261102']['array_sha256']['y']=='6172de6b43091361c783185cd6547de18481f9fa5a84609e675e0dd3e262d271'
    assert frozen['seeds']['20261102']['canonical_train_sha256']=='2986b25a1dcb2421f9c2b15445a75b6ade5595469ad1362b6da6656ec1b30e93'
    assert frozen['seeds']['20261102']['target_sha256']=='57ac66bf228737e9461ef2ae8c1b569768ac02b0391f14aa30791676ce30eaf6'
    print('FREEZE PASSED')
