"""Exactly 36 job solver matrix: 3 seeds × 2 sizes × 3 classes × 2 inits."""
import subprocess,sys,json,os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
cases=[(s,n,c,ini) for s in (20261102,20261103,20261104) for n in (150,300) for c in range(3) for ini in ('zero','random')]
assert len(cases)==36
progress=[]
for i,(s,n,c,ini) in enumerate(cases):
    dest=ROOT/'results'/f'solver_s{s}_n{n}_class{c}_{ini}.json'
    if dest.exists():
      z=json.loads(dest.read_text());assert z['Q_steps_completed']==100 and z['GN_max_steps']==30
      msg='EXISTS';code=0
    else:
      cmd=[sys.executable,str(ROOT/'src/solve_bayes.py'),'--seed',str(s),'--n',str(n),'--class',str(c),'--init',ini]
      try:
        r=subprocess.run(cmd,env=os.environ,capture_output=True,text=True,timeout=1200)
        code=r.returncode
      except subprocess.TimeoutExpired as e:
        code=124;r=e
      msg='PASS' if code==0 and dest.exists() else 'FAIL'
    row={'index':i,'seed':s,'n':n,'class':c,'init':ini,'status':msg}
    if msg in ('PASS','EXISTS'):
      z=json.loads(dest.read_text());row['JSD']=z['best_exact_JSD'];row['wall']=z['wall_seconds'];assert z['Q_steps_completed']==100 and z['GN_max_steps']==30
    elif msg=='FAIL':row['stderr']=str(getattr(r,'stderr',''))[-1600:]
    progress.append(row)
    (ROOT/'logs/solver_progress.json').write_text(json.dumps({'jobs':progress,'complete':sum(x['status'] in ('PASS','EXISTS') for x in progress)},indent=2)+'\n')
    print(f'[{i+1:2d}/36] {msg} {s} n{n} class{c} {ini}'+(f" jsd={row['JSD']:.7f} wall={row['wall']:.1f}s" if 'JSD' in row else ' '+row.get('stderr','')),flush=True)
    if msg=='FAIL':break
print('END jobs',len(progress),'passed',sum(x['status'] in ('PASS','EXISTS') for x in progress),flush=True)
