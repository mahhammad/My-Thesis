import subprocess,sys,json,os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
entries=[(s,n) for s in (20261102,20261103,20261104) for n in (150,300)]
for i,(s,n) in enumerate(entries):
  f=ROOT/'checks'/f'precision_s{s}_n{n}_H12.json'
  if f.exists():print(f'[{i+1}/6] EXISTS {s} {n}',flush=True);continue
  cmd=[sys.executable,str(ROOT/'src/precision_verify.py'),'--seed',str(s),'--n',str(n)]
  try:
   r=subprocess.run(cmd,env=os.environ,timeout=180,capture_output=True,text=True,check=True)
   print(f'[{i+1}/6] '+r.stdout.strip(),flush=True)
  except Exception as e:print('STOP',str(e),r.stderr if 'r' in locals() else '',flush=True);break
