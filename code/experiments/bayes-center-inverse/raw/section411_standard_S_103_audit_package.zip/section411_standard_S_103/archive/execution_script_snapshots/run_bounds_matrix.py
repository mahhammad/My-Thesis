import subprocess,json,sys,os,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
P=[(1,.4,.8),(2,.4,.8),(3,.4,.8),(4,.4,.8),(12,.4,.8),(12,.2,.8),(12,.7,.8),(12,.4,.4),(12,.4,1.)]
assert len(set(P))==9
configs=[(seed,n,H,b,l) for seed in (20261102,20261103,20261104) for n in (150,300) for H,b,l in P]
assert len(configs)==54
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1')
statuses=[]
for i,(s,n,H,b,l) in enumerate(configs):
    outfile=ROOT/'results'/f'bounds_s{s}_n{n}_H{H}_b{str(b).replace(".","p")}_l{str(l).replace(".","p")}.json'
    if outfile.exists():
      z=json.loads(outfile.read_text())
      statuses.append({'seq':i,'config':[s,n,H,b,l],'status':'PRESENT','wall':z['bound_wall_seconds']})
      print(f'[{i+1:2d}/54] EXISTS {s} n{n} H{H} b{b} l{l}',flush=True)
      continue
    cmd=[sys.executable,str(ROOT/'src/bounds_run.py'),'--seed',str(s),'--n',str(n),'--H',str(H),'--beta',str(b),'--lam',str(l)]
    start=time.perf_counter()
    try:
      r=subprocess.run(cmd,env=os.environ,capture_output=True,text=True,timeout=120,check=True)
      z=json.loads(outfile.read_text())
      statuses.append({'seq':i,'config':[s,n,H,b,l],'status':'PASS','wall':z['bound_wall_seconds'],'rss_mib':z['peak_rss_mib_linux']})
      print(f'[{i+1:2d}/54] PASS {s} n{n} H{H} b{b} l{l} wall {z["bound_wall_seconds"]:.2f}s',flush=True)
    except Exception as e:
      statuses.append({'seq':i,'config':[s,n,H,b,l],'status':'FAIL','error':str(e),'output':r.stderr if 'r' in locals() else ''})
      print('STOP FAIL',statuses[-1],flush=True);break
    finally:
      (ROOT/'logs'/'bounds_matrix_progress.json').write_text(json.dumps({'results':statuses,'count':len(statuses),'passed':sum(x['status'] in ('PASS','PRESENT') for x in statuses)},indent=2)+'\n')
print('COMPLETE',len(statuses),sum(x['status'] in ('PASS','PRESENT') for x in statuses), 'wall_sec',sum(x.get('wall',0) for x in statuses),flush=True)
