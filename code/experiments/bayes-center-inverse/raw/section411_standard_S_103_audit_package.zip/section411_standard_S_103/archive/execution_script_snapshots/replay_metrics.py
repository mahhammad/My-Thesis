"""§4.11 independent NumPy replay of 3 frozen class policy matrices.
Train representations use original no-return origin-excluded exact graph.
Validation and Test use no in-graph origin and original heldout feature kernels.
Classifier: argmin JSD(representation under class policy c, realized Train center V_c).
All decisions & model selection use Train ONLY. Heldout scores evaluated postfit.
"""
import argparse,hashlib,itertools,json,math,os,resource,time
from pathlib import Path
import numpy as np
from generate_frozen import spec,sha
from bounds_run import subset150,alpha_from_project
ROOT=Path(__file__).resolve().parents[1]

def entropy(a):
    a=np.asarray(a,float)
    return -np.sum(np.where(a>0,a*np.log(np.clip(a,1e-300,None)),0),axis=-1)
def kl(a,b):
    a=np.asarray(a,float);b=np.asarray(b,float)
    # Safe exact support condition: positive mass where target zero => infinity.
    bad=np.any((a>0)&(b==0),axis=-1)
    t=np.sum(np.where(a>0,a*(np.log(np.clip(a,1e-300,None))-np.log(np.clip(b,1e-300,None))),0),axis=-1)
    return np.where(bad,np.inf,np.maximum(0,t))
def jsd(a,b):
    a=np.asarray(a,float);b=np.asarray(b,float);m=.5*(a+b)
    return np.maximum(0,.5*kl(a,m)+.5*kl(b,m))
def feature_kernel(x,gamma):
    n,d=x.shape; B=np.empty((d,n,n),float)
    for b in range(d):
      ok=np.isfinite(x[:,b]);v=np.where(ok,x[:,b],0)
      W=np.exp(-gamma[b]*(v[:,None]-v[None,:])**2);W*=ok[:,None]&ok[None,:]
      np.fill_diagonal(W,0)
      den=W.sum(axis=1,keepdims=True)
      np.divide(W,den,out=W,where=den>0)
      B[b]=W
    return B

def heldout_start(query,x,gamma):
    m,d=query.shape;n=len(x);start=np.empty((m,n,d),float)
    for b in range(d):
       obs=np.isfinite(query[:,b]);ref=np.isfinite(x[:,b])
       qv=np.where(obs,query[:,b],0);rv=np.where(ref,x[:,b],0)
       W=np.exp(-gamma[b]*(qv[:,None]-rv[None,:])**2)*(obs[:,None]&ref[None,:]);den=W.sum(1,keepdims=True)
       np.divide(W,den,out=W,where=den>0)
       start[:,:,b]=W
    return start

def masked_softmax(logits,mask):
    z=np.broadcast_to(logits,mask.shape).copy();z[~mask]=-1e20
    z-=z.max(axis=-1,keepdims=True)
    e=np.exp(z);e[~mask]=0
    den=e.sum(axis=-1,keepdims=True)
    if np.any(den<=0):
       # For unreachable incoming states all actions masked, policy irrelevant.
       return np.divide(e,den,out=np.zeros_like(e),where=den>0)
    return e/den

class Replayer:
 def __init__(self,x,y,gamma,H=12,beta=.4,lam=.8):
    self.x=np.asarray(x,float);self.y=np.asarray(y,int);self.n,self.d=self.x.shape;self.K=int(self.y.max())+1
    self.gamma=gamma;self.B=feature_kernel(x,gamma);self.alpha=alpha_from_project(beta,lam,H)
    self.Y=np.eye(self.K)[self.y];self.valid_x=np.isfinite(x)
    self.den=np.empty((self.n,self.n,self.d),float)
    for s in range(self.n):
      for b in range(self.d):
         self.den[s,:,b]=self.B[b,:,:s].sum(axis=1)+self.B[b,:,s+1:].sum(axis=1)
    self.legal=self.den>1e-12
    if not self.legal.any(axis=2).all():raise ArithmeticError('dead-end')
    self.start=np.transpose(self.B,(1,2,0))
    assert np.abs(self.B.sum(2).T[self.valid_x]-1).max()<1e-10
 def train(self,z):
    n,d=self.n,self.d;ids=np.arange(n)
    p0=masked_softmax(np.broadcast_to(z[d],(n,d)),self.valid_x)
    state=self.start*p0[:,None,:]
    p=masked_softmax(np.broadcast_to(z[:d],(n,n,d,d)),np.broadcast_to(self.legal[:,:,None,:],(n,n,d,d)))
    out=np.zeros((n,self.K))
    for t in range(len(self.alpha)):
      out+=self.alpha[t]*np.einsum('sia,ik->sk',state,self.Y,optimize=True)
      if t==len(self.alpha)-1:break
      choose=np.einsum('sia,siab->sib',state,p,optimize=True)
      steps=[]
      for b in range(d):
        w=np.divide(choose[:,:,b],self.den[:,:,b],out=np.zeros((n,n)),where=self.legal[:,:,b])
        new=w@self.B[b]
        new[ids,ids]=0
        steps.append(new)
      state=np.stack(steps,axis=-1)
    if np.max(np.abs(out.sum(axis=1)-1))>1e-8:raise ArithmeticError('train mass lost')
    return out
 def heldout(self,z,query):
    query=np.asarray(query,float);m=len(query);n,d=self.n,self.d
    first=heldout_start(query,self.x,self.gamma)
    p0=masked_softmax(np.broadcast_to(z[d],(m,d)),np.isfinite(query))
    state=first*p0[:,None,:]
    valid=self.B.sum(axis=2).T>1e-12
    p=masked_softmax(np.broadcast_to(z[:d],(n,d,d)),np.broadcast_to(valid[:,None,:],(n,d,d)))
    out=np.zeros((m,self.K))
    for t in range(len(self.alpha)):
      out+=self.alpha[t]*np.einsum('mib,ic->mc',state,self.Y,optimize=True)
      if t==len(self.alpha)-1:break
      choose=np.einsum('mia,iab->mib',state,p,optimize=True)
      state=np.stack([choose[:,:,b]@self.B[b] for b in range(d)],axis=-1)
    if np.max(np.abs(out.sum(axis=1)-1))>1e-8:raise ArithmeticError('heldout mass lost')
    return out

def geometry(centers):
    K=len(centers);v=centers.mean(0)
    I=float(entropy(v)-entropy(centers).mean())
    T=float(np.diag(centers).mean())
    BT=max(float(np.mean([centers[c,perm[c]] for c in range(K)])) for perm in itertools.permutations(range(K)))
    TNL=float(-np.log(np.diag(centers)).mean()) if np.min(np.diag(centers))>0 else None
    BTNL=min(float(np.mean([-math.log(centers[c,perm[c]]) for c in range(K)])) if min(centers[c,perm[c]] for c in range(K))>0 else math.inf for perm in itertools.permutations(range(K)))
    pairs=[{'classes':[a,b],'JSD':float(jsd(centers[a],centers[b])),'sqrt_JSD':float(math.sqrt(jsd(centers[a],centers[b])))} for a,b in itertools.combinations(range(K),2)]
    return {'I':I,'T':T,'BT':BT,'TNL':TNL,'BTNL':BTNL if math.isfinite(BTNL) else None,'pairwise_center_distances':pairs,'min_pairwise_sqrt_JS':min(p['sqrt_JSD'] for p in pairs),'mean_pairwise_sqrt_JS':sum(p['sqrt_JSD'] for p in pairs)/len(pairs)}

def score_split(Q,centers,y,split,tau=.005):
    # Q shape sample × candidate class × label probabilities.
    N,K,_=Q.shape; y=np.asarray(y,int)
    if len(y)!=N or not set(range(K)).issubset(set(y)):raise ValueError('classes missing for BA')
    dist=jsd(Q,centers[None,:,:]);sim=1-dist/np.log(2.)
    prediction=np.argmin(dist,axis=1)
    hits=(prediction==y)
    conf=np.stack([np.bincount(prediction[y==c],minlength=K) for c in range(K)])
    own=Q[np.arange(N),y,:];vown=centers[y]
    rjs=jsd(own,vown);root=np.sqrt(rjs);rkl=kl(own,vown)
    ownsim=sim[np.arange(N),y];other=sim.copy();other[np.arange(N),y]=-np.inf
    margin=ownsim-other.max(axis=1)
    sigloss=1/(1+np.exp(np.clip(margin/tau,-700,700)))
    nll=np.log(np.exp(sim-sim.max(axis=1,keepdims=True)).sum(axis=1))+sim.max(axis=1)-ownsim
    per=[{'class':int(c),'n':int(np.sum(y==c)),'accuracy':float(hits[y==c].mean()),'R_JS':float(rjs[y==c].mean()),'R_sqrt_JS':float(root[y==c].mean()),'R_KL':float(rkl[y==c].mean())} for c in range(K)]
    permean=lambda a:float(np.mean([a[y==c].mean() for c in range(K)]))
    res={'split':split,'N':N,'balanced_accuracy':permean(hits.astype(float)),'ordinary_accuracy':float(hits.mean()),'confusion_true_rows_pred_cols':conf.tolist(),'R_KL':permean(rkl),'R_JS':permean(rjs),'R_sqrt_JS':permean(root),'balanced_hard_margin_error':permean((margin<=0).astype(float)),'balanced_sigmoid_margin_loss':permean(sigloss),'balanced_JS_similarity_NLL':permean(nll),'margin_quantiles':{str(t):float(np.quantile(margin,t)) for t in (0,.1,.25,.5,.75,.9,1)},'per_class':per,'predictions':prediction.tolist(),'true_labels':y.tolist(),'margins':margin.tolist(),'per_sample_own_R_JS':rjs.tolist(),'per_sample_own_R_KL':rkl.tolist(),'per_sample_own_sqrtJS':root.tolist(),'hypothesis_representations':Q.tolist(),'scores_JS_similarity':sim.tolist()}
    if split=='train':
       Ent=entropy(centers)-np.array([entropy(own[y==c]).mean() for c in range(K)])
       res['R_KL_entropy_identity']=float(Ent.mean())
       if abs(res['R_KL_entropy_identity']-res['R_KL'])>1e-8:raise AssertionError('Train KL entropy identity mismatch')
    else:res['R_KL_entropy_identity']=None
    return res

def run(seed,n):
    t0=time.perf_counter();f=ROOT/'results'/f'replay_s{seed}_n{n}.json'
    if f.exists():raise FileExistsError(str(f))
    dat={name:np.load(ROOT/'data'/f'{name}_{seed}.npz') for name in ('train','validation','test')}
    yall=dat['train']['y'];refids=np.arange(300) if n==300 else subset150(seed,yall)
    x=dat['train']['x'][refids];y=yall[refids]
    gr=Replayer(x,y,spec(seed)['gamma'])
    policies=[];selected=[]
    for c in range(3):
      runs=[]
      for ini in ('zero','random'):
        v=json.loads((ROOT/'results'/f'solver_s{seed}_n{n}_class{c}_{ini}.json').read_text())
        assert v['Q_steps_completed']==100 and v['GN_max_steps']==30
        runs.append(v)
      v=min(runs,key=lambda z:z['best_exact_JSD'])
      policies.append(np.array(v['z'],float))
      selected.append({'class':c,'selected_initialization':v['initialization'],'selected_exact_train_JSD':v['best_exact_JSD'],'all_initialization_JSD':{q['initialization']:q['best_exact_JSD'] for q in runs},'selection_rule':'TRAIN only best exact center JSD'})
    results={}
    for policy_name,zs in (('Bayes_target_Q100_GN30',policies),('uniform', [np.zeros_like(policies[0])]*3)):
       train_by=np.stack([gr.train(z) for z in zs],axis=1)
       centers=np.stack([train_by[y==c,c].mean(axis=0) for c in range(3)])
       if policy_name!='uniform':
          for c in range(3):
            loss=float(jsd(centers[c],np.load(ROOT/'data'/f'bayes_target_{seed}.npy')[c]))
            if abs(loss-selected[c]['selected_exact_train_JSD'])>1e-10:raise AssertionError(f'Independent replay mismatch class{c}: {loss} != {selected[c]["selected_exact_train_JSD"]}')
       validation_by=np.stack([gr.heldout(z,dat['validation']['x']) for z in zs],axis=1)
       test_by=np.stack([gr.heldout(z,dat['test']['x']) for z in zs],axis=1)
       metrics={s:score_split(Q,centers,labels,s) for s,Q,labels in [('train',train_by,y),('validation',validation_by,dat['validation']['y']),('test',test_by,dat['test']['y'])]}
       results[policy_name]={'centers':centers.tolist(),'center_geometry':geometry(centers),'metrics':metrics,'policy_selection':selected if policy_name!='uniform' else None}
    report={'status':'PASS_INDEPENDENT_NUMPY_FORWARD_REPLAY','seed':seed,'n':n,'reference_ids_sha256':sha(np.array(refids,dtype='<i8').tobytes()),'center_target_origin':'Bayes posterior over corresponding whole Train300','selection':'Train exact JSD only; Validation/Test never enter optimizer','results':results,'wall_seconds':time.perf_counter()-t0,'peak_rss_mib_linux':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024,'metric_contract':'Chapter4 common contract v2 (R_KL, R_JS, R_sqrt_JS, I,T,BT,TNL,BTNL,BA,confusion,margin,sim-NLL)','tau':.005}
    f.write_text(json.dumps(report,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(json.dumps({'seed':seed,'n':n,'wall':round(report['wall_seconds'],2),'BA':{k:{s:round(m['balanced_accuracy'],5) for s,m in v['metrics'].items()} for k,v in results.items()},'mean_Bayes_JSD':float(np.mean([v['selected_exact_train_JSD'] for v in selected]))}),flush=True)
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--seed',type=int,required=True);p.add_argument('--n',type=int,required=True);a=p.parse_args();run(a.seed,a.n)
